# powershell -ExecutionPolicy Bypass -File .\psql_var.ps1
$env:PGPASSWORD = "interline"

$TARGET_ID = 3
psql -U postgres -d testDB -c "SELECT * FROM users WHERE id = $TARGET_ID;"

$TARGET_EMAIL = "sakura@example.com"
psql -U postgres -d testDB -c "SELECT name, created_at FROM users WHERE email = '$TARGET_EMAIL';"

# ファイルに変数渡しのとき、-vを使う
psql -U postgres -d testDB -v target_id=6 -f ./users_search.sql
$env:PGPASSWORD = $null