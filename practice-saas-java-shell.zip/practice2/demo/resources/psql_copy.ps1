# powershell -ExecutionPolicy Bypass -File .\psql_copy.ps1
$env:PGPASSWORD = "interline"

# \copy users TO 'C:\Users\interline\Downloads\users_list.csv' WITH CSV HEADER; # psqlの中で
# COPY users TO 'C:\Users\interline\Downloads\users_list.csv' WITH CSV HEADER; # 権限があればこちらが早いとのこと
# psql -U postgres -d testDB -c "\copy users TO 'C:\Users\interline\Downloads\users_export.csv' WITH (FORMAT CSV, HEADER)"
psql -U postgres -d testDB -c "\copy users TO 'C:\Users\interline\Downloads\users_export.csv' WITH CSV HEADER" # WITH (FORMAT CSV, HEADER) 同じ

$env:PGPASSWORD = $null