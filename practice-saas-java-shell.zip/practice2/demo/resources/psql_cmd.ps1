# powershell -ExecutionPolicy Bypass -File .\psql_cmd.ps1
$env:PGPASSWORD = "interline"
psql -U postgres -d testDB -c "SELECT * FROM users"
psql -U postgres -d testDB -f ./users_select.sql
$env:PGPASSWORD = $null