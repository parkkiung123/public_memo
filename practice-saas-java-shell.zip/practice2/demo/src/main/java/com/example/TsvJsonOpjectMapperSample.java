package com.example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.core.type.TypeReference;

public class TsvJsonOpjectMapperSample {

    final static Path dirPath = Path.of("C:\\Users\\interline\\Documents\\Codex\\2026-05-13\\saas-java-11-api-45-db\\practice2\\demo\\resources");

    static void tsv2json() {
        Path inputPath = dirPath.resolve("employee.tsv");
        Path outputPath = dirPath.resolve("employee.json");

        List<Map<String, String>> employeeList = new ArrayList<>();

        try (BufferedReader reader = Files.newBufferedReader(inputPath, StandardCharsets.UTF_8)) {

            String line;

            // ヘッダ取得
            String headerLine = reader.readLine();

            if (headerLine == null) {
                System.out.println("TSVファイルが空です");
                return;
            }

            String[] headers = headerLine.split("\t");

            // データ行読込
            while ((line = reader.readLine()) != null) {

                String[] values = line.split("\t");

                Map<String, String> employee = new LinkedHashMap<>();

                for (int i = 0; i < headers.length; i++) {

                    String key = headers[i];
                    String value = i < values.length ? values[i] : "";

                    employee.put(key, value);
                }

                employeeList.add(employee);
            }

            // JSON変換
            ObjectMapper mapper = new ObjectMapper();
            mapper.enable(SerializationFeature.INDENT_OUTPUT);

            String json = mapper.writeValueAsString(employeeList);

            // JSONファイル保存
            try (BufferedWriter writer = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {

                writer.write(json);
            }

            System.out.println("JSONファイル出力完了");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void jsonValidation() {

        Path jsonPath = dirPath.resolve("employee.json");
        
        try (BufferedReader reader = Files.newBufferedReader(jsonPath)) {
            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            String json = sb.toString();
            ObjectMapper mapper = new ObjectMapper();

            List<Map<String, String>> list =
                    mapper.readValue(json, new TypeReference<List<Map<String, String>>>() {});

            // 正規表現
            Pattern emailPattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
            Pattern phonePattern = Pattern.compile("^0\\d{1,4}-?\\d{1,4}-?\\d{4}$");

            List<Map<String, String>> validList = new ArrayList<>();
            List<Map<String, String>> errorList = new ArrayList<>();

            for (Map<String, String> emp : list) {

                // ===== 文字列操作 =====
                String email = emp.get("メールアドレス").toLowerCase();
                emp.put("メールアドレス", email);

                String phone = emp.get("携帯番号").replace("-", "");
                emp.put("携帯番号", phone);

                // ===== バリデーション =====
                boolean emailOk = emailPattern.matcher(email).matches();
                boolean phoneOk = phonePattern.matcher(emp.get("携帯番号")).matches();

                if (emailOk && phoneOk) {
                    validList.add(emp);
                } else {
                    emp.put("エラー理由",
                            (!emailOk ? "メール不正 " : "") +
                            (!phoneOk ? "電話不正" : ""));
                    errorList.add(emp);
                }
            }

            // ===== 結果出力 =====
            System.out.println("=== 正常データ ===");
            System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(validList));

            System.out.println("\n=== エラーデータ ===");
            System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(errorList));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        tsv2json();
        jsonValidation();
    }
}
