package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCSample {

    private static final String URL = "jdbc:mysql://localhost:3306/crm";
    private static final String USER = "root";
    private static final String PASS = "1234";

    static void select() {
        String sql = "SELECT user_id, user_login_id, user_name, email, phone_number " +
                "FROM userlist WHERE enabled = ?";

        try (
                Connection conn = DriverManager.getConnection(URL, USER, PASS);
                PreparedStatement ps = conn.prepareStatement(sql);) {

            ps.setBoolean(1, true);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    int userId = rs.getInt("user_id");
                    String loginId = rs.getString("user_login_id");
                    String userName = rs.getString("user_name");
                    String email = rs.getString("email");
                    String phone = rs.getString("phone_number");

                    System.out.println(
                            userId + " | " +
                                    loginId + " | " +
                                    userName + " | " +
                                    email + " | " +
                                    phone);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void insert() {
        String sql = "INSERT INTO userlist " +
                "(user_login_id, user_name, password, email, phone_number, registration_date, register_member_id, enabled) "
                +
                "VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)";

        try (
                Connection conn = DriverManager.getConnection(URL, USER, PASS);
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "test_user");
            ps.setString(2, "テストユーザ");
            ps.setString(3, "pass123");
            ps.setString(4, "test@example.com");
            ps.setString(5, "090-1234-5678");
            ps.setInt(6, 1);
            ps.setBoolean(7, true);

            int result = ps.executeUpdate();

            System.out.println("INSERT件数: " + result);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void update() {
        String sql = "UPDATE userlist SET user_name = ?, email = ?, update_date = NOW() " +
                "WHERE user_id = ?";

        try (
                Connection conn = DriverManager.getConnection(URL, USER, PASS);
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "更新ユーザ");
            ps.setString(2, "update@test.com");
            ps.setInt(3, 44);

            int result = ps.executeUpdate();

            System.out.println("UPDATE件数: " + result);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void delete() {

        String sql = "DELETE FROM userlist WHERE user_login_id = ?";

        try (
                Connection conn = DriverManager.getConnection(URL, USER, PASS);
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "test_user");

            int result = ps.executeUpdate();

            System.out.println("DELETE件数: " + result);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        select();
        insert();
        update();
        delete();
    }
}
