package com.example;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class HttpClientExercise {

    private final HttpClient client;

    // コンストラクタでHttpClientを初期化
    public HttpClientExercise() {
        this.client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    // GET通信のテストメソッド
    public void get_test() {
        System.out.println("--- Executing GET Test ---");
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/posts/1"))
                .timeout(Duration.ofSeconds(5))
                .header("Accept", "application/json")
                .GET()
                .build();

        sendRequest(request);
    }

    // POST通信のテストメソッド
    public void post_test() {
        System.out.println("--- Executing POST Test ---");
        String jsonPayload = "{"
                + "\"title\": \"経理伝票連携\","
                + "\"body\": \"間接材システムからの自動送信データ\","
                + "\"userId\": 1"
                + "}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/posts"))
                .timeout(Duration.ofSeconds(5))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();

        sendRequest(request);
    }

    // 送信処理の共通化
    private void sendRequest(HttpRequest request) {
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Status Code: " + response.statusCode());
            System.out.println("Response Body: " + response.body());
        } catch (Exception e) {
            System.err.println("Communication Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        HttpClientExercise manager = new HttpClientExercise();
        
        // 各テストメソッドの実行
        manager.get_test();
        System.out.println(); // 改行用
        manager.post_test();
    }
}