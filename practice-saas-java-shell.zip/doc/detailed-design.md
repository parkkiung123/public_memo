# ロト6 API 詳細設計書

作成日: 2026-05-14

## 1. この資料で作成するもの

| 名前 | 意味 | 今回の作成状況 |
|---|---|---|
| 詳細設計書 | 実装に近い仕様をまとめる資料 | 作成 |
| プログラム設計書 | プログラム単位の役割をまとめる資料 | 作成 |
| クラス設計書・モジュール設計書 | クラスやモジュールの責務をまとめる資料 | 作成 |
| 処理フロー | 処理の流れを順番に示す資料 | 作成 |
| 入出力項目定義 | リクエスト、レスポンス、画面入力、画面出力の項目定義 | 作成 |
| DB詳細設計書 | DBの使い方、制約、方針をまとめる資料 | 作成 |
| テーブル定義書 | テーブル、カラム、型、キーを定義する資料 | 作成 |
| SQL設計書 | 使用するSQLをまとめる資料 | 作成 |
| API詳細設計書 | APIのURL、メソッド、項目、エラーを定義する資料 | 作成 |
| バッチ詳細設計書 | 定期実行処理の詳細 | 該当なし |
| エラー処理設計書 | エラー時の扱いを定義する資料 | 作成 |
| ログ出力設計書 | どのタイミングで何をログに出すかを定義する資料 | 作成 |
| メッセージ一覧 | 画面やAPIで返すメッセージの一覧 | 作成 |
| 単体テスト仕様書 | JUnitなどで確認するテスト観点 | 作成 |

## 2. 前提

本詳細設計書は、DBを使用する構成を前提とする。

DB製品は未確定のため、型は一般的なRDBまたはPostgreSQL相当で記載する。

外部APIの正式仕様は未確定のため、外部APIレスポンスは想定形式として記載する。

## 3. プログラム設計書

| プログラムID | プログラム名 | 種別 | 役割 |
|---|---|---|---|
| PG-001 | React画面 | フロントエンド | 番号入力、API呼び出し、結果表示を行う |
| PG-002 | Loto6Servlet | Servlet | HTTPリクエストを受け付け、サービスを呼び出す |
| PG-003 | Loto6Service | 業務ロジック | 入力チェック、当選判定、おすすめ番号算出を行う |
| PG-004 | Loto6Repository | DBアクセス | 抽選履歴の検索、登録、更新を行う |
| PG-005 | Loto6ApiClient | 外部API連携 | ロト6歴代当選番号APIを呼び出す |
| PG-006 | JsonResponseWriter | 共通部品 | APIレスポンスJSONを生成する |

## 4. クラス設計書・モジュール設計書

| クラス名 | 主なメソッド | 責務 |
|---|---|---|
| `Loto6Servlet` | `doGet`, `doPost` | `/api/check`、`/api/recommend` の入口 |
| `Loto6Service` | `check`, `recommend`, `refreshDrawsIfNeeded` | 業務ルールを実行する |
| `Loto6Repository` | `findAllDraws`, `upsertDraws`, `findLatestDraw` | DBの抽選履歴を操作する |
| `Loto6ApiClient` | `fetchDraws` | 外部APIから抽選履歴を取得する |
| `Loto6Record` | フィールド保持 | 1開催回分の抽選結果を表す |
| `WinningResult` | フィールド保持 | 当選判定結果を表す |
| `Recommendation` | フィールド保持 | おすすめ番号と根拠を表す |

## 5. 処理フロー

### 5.1 当選チェック処理

```mermaid
flowchart TD
  A["開始"] --> B["リクエストからnumbers取得"]
  B --> C["入力チェック"]
  C --> D{"DBに抽選履歴あり？"}
  D -->|"あり"| F["DBから抽選履歴取得"]
  D -->|"なし"| E["外部APIから取得してDB保存"]
  E --> F
  F --> G["入力番号と各開催回を照合"]
  G --> H["ランクと賞金を判定"]
  H --> I["JSONレスポンス返却"]
  I --> J["終了"]
```

### 5.2 おすすめ番号取得処理

```mermaid
flowchart TD
  A["開始"] --> B{"DBに抽選履歴あり？"}
  B -->|"あり"| D["DBから抽選履歴取得"]
  B -->|"なし"| C["外部APIから取得してDB保存"]
  C --> D
  D --> E["全期間の出現頻度を集計"]
  E --> F["直近100回を重み付け"]
  F --> G["今日の日付シードを加算"]
  G --> H["上位6数字を選択"]
  H --> I["JSONレスポンス返却"]
```

### 5.3 外部API取込処理

```mermaid
flowchart TD
  A["開始"] --> B["外部API呼び出し"]
  B --> C{"取得成功？"}
  C -->|"成功"| D["レスポンスを抽選結果モデルへ変換"]
  D --> E["DBへ登録・更新"]
  E --> F["取込ログ登録"]
  C -->|"失敗"| G["エラーログ登録"]
  G --> H["APIエラーとして返却"]
```

## 6. 入出力項目定義

### 6.1 画面入力

| 項目名 | 型 | 必須 | 内容 | 入力例 |
|---|---|---|---|---|
| numbers | 文字列 | 必須 | スペース区切りの6数字 | `1 17 29 33 40 42` |

### 6.2 画面出力

| 項目名 | 内容 |
|---|---|
| おすすめ番号 | APIから返された6個の数字 |
| 当選結果一覧 | 開催回、日付、ランク、賞金、一致数 |
| エラーメッセージ | 入力不正やシステムエラーの説明 |

### 6.3 入力チェック

| チェックID | 項目 | 条件 | エラー時 |
|---|---|---|---|
| V-001 | numbers | 未入力でないこと | `MSG-E001` |
| V-002 | numbers | スペース区切りで6個であること | `MSG-E002` |
| V-003 | numbers | すべて数値であること | `MSG-E003` |
| V-004 | numbers | 1から43の範囲であること | `MSG-E004` |
| V-005 | numbers | 重複がないこと | `MSG-E005` |

## 7. DB詳細設計書

### 7.1 DB利用方針

| 項目 | 方針 |
|---|---|
| 保存対象 | ロト6抽選履歴、外部API取込履歴 |
| 更新方式 | 開催回をキーに登録または更新する |
| 参照方式 | 当選チェック、おすすめ番号算出時に抽選履歴を取得する |
| トランザクション | 外部API取込時は抽選履歴保存と取込ログ保存を同一トランザクションにする |
| 文字コード | UTF-8 |

## 8. テーブル定義書

### 8.1 loto6_draw

| カラム名 | 型 | PK | NOT NULL | 内容 |
|---|---|---|---|---|
| draw_no | integer | Yes | Yes | 開催回 |
| draw_date | date | No | Yes | 抽選日 |
| number1 | integer | No | Yes | 第1数字 |
| number2 | integer | No | Yes | 第2数字 |
| number3 | integer | No | Yes | 第3数字 |
| number4 | integer | No | Yes | 第4数字 |
| number5 | integer | No | Yes | 第5数字 |
| number6 | integer | No | Yes | 第6数字 |
| bonus_number | integer | No | Yes | BONUS数字 |
| first_prize | bigint | No | Yes | 1等賞金 |
| second_prize | bigint | No | Yes | 2等賞金 |
| third_prize | bigint | No | Yes | 3等賞金 |
| fourth_prize | bigint | No | Yes | 4等賞金 |
| fifth_prize | bigint | No | Yes | 5等賞金 |
| created_at | timestamp | No | Yes | 作成日時 |
| updated_at | timestamp | No | Yes | 更新日時 |

### 8.2 loto6_api_import_log

| カラム名 | 型 | PK | NOT NULL | 内容 |
|---|---|---|---|---|
| import_id | bigint | Yes | Yes | 取込ID |
| imported_at | timestamp | No | Yes | 取込日時 |
| status | varchar(20) | No | Yes | `SUCCESS` または `FAILED` |
| imported_count | integer | No | Yes | 取込件数 |
| message | varchar(1000) | No | No | メッセージ |

## 9. SQL設計書

### 9.1 抽選履歴全件取得

```sql
SELECT
  draw_no,
  draw_date,
  number1,
  number2,
  number3,
  number4,
  number5,
  number6,
  bonus_number,
  first_prize,
  second_prize,
  third_prize,
  fourth_prize,
  fifth_prize
FROM loto6_draw
ORDER BY draw_no DESC;
```

### 9.2 最新開催回取得

```sql
SELECT MAX(draw_no) AS latest_draw_no
FROM loto6_draw;
```

### 9.3 抽選履歴登録・更新

```sql
INSERT INTO loto6_draw (
  draw_no,
  draw_date,
  number1,
  number2,
  number3,
  number4,
  number5,
  number6,
  bonus_number,
  first_prize,
  second_prize,
  third_prize,
  fourth_prize,
  fifth_prize,
  created_at,
  updated_at
) VALUES (
  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
)
ON CONFLICT (draw_no) DO UPDATE SET
  draw_date = EXCLUDED.draw_date,
  number1 = EXCLUDED.number1,
  number2 = EXCLUDED.number2,
  number3 = EXCLUDED.number3,
  number4 = EXCLUDED.number4,
  number5 = EXCLUDED.number5,
  number6 = EXCLUDED.number6,
  bonus_number = EXCLUDED.bonus_number,
  first_prize = EXCLUDED.first_prize,
  second_prize = EXCLUDED.second_prize,
  third_prize = EXCLUDED.third_prize,
  fourth_prize = EXCLUDED.fourth_prize,
  fifth_prize = EXCLUDED.fifth_prize,
  updated_at = CURRENT_TIMESTAMP;
```

### 9.4 取込ログ登録

```sql
INSERT INTO loto6_api_import_log (
  imported_at,
  status,
  imported_count,
  message
) VALUES (
  CURRENT_TIMESTAMP,
  ?,
  ?,
  ?
);
```

## 10. API詳細設計書

### 10.1 API一覧

| API ID | 名前 | メソッド | URL | 概要 |
|---|---|---|---|---|
| API-001 | 当選チェックAPI | GET | `/loto6-api/api/check?numbers=1%2017%2029%2033%2040%2042` | 入力番号の過去当選結果を返す |
| API-002 | 当選チェックAPI | POST | `/loto6-api/api/check` | リクエスト本文の番号で過去当選結果を返す |
| API-003 | おすすめ番号API | GET | `/loto6-api/api/recommend` | 今日のおすすめ番号を返す |

### 10.2 API-001/API-002 当選チェックAPI

リクエスト:

| 項目名 | 場所 | 型 | 必須 | 内容 |
|---|---|---|---|---|
| numbers | queryまたはbody | string | Yes | スペース区切りの6数字 |

レスポンス:

```json
{
  "requestNumbers": [1, 17, 29, 33, 40, 42],
  "winningCount": 1,
  "winnings": [
    {
      "drawNo": 2101,
      "date": "2026/5/11",
      "rank": "1等",
      "amount": 119417600,
      "mainMatches": 6,
      "bonusMatch": false
    }
  ]
}
```

### 10.3 API-003 おすすめ番号API

リクエスト項目なし。

レスポンス:

```json
{
  "recommendedNumbers": [1, 17, 29, 33, 40, 42],
  "method": "DBに保存された過去データを使い、全期間の出現頻度、直近100回の重み、今日の日付シードを使ったスコア順です。",
  "latestDraw": {
    "drawNo": 2101,
    "date": "2026/5/11"
  },
  "basis": []
}
```

### 10.4 HTTPステータス

| ステータス | 条件 |
|---|---|
| 200 | 正常終了 |
| 400 | 入力不正 |
| 500 | システムエラー、DBエラー、外部APIエラー |

## 11. 外部API詳細設計

### 11.1 EXT-001 ロト6歴代当選番号取得API

| 項目 | 内容 |
|---|---|
| メソッド | GET |
| 接続先 | 外部APIの正式URLが決まり次第確定 |
| 認証 | 必要な場合はAPIキーを環境変数で管理 |
| タイムアウト | 10秒 |
| リトライ | 原則なし。将来必要に応じて追加 |

想定レスポンス:

```json
[
  {
    "drawNo": 2101,
    "date": "2026/5/11",
    "numbers": [1, 17, 29, 33, 40, 42],
    "bonusNumber": 21,
    "prizes": {
      "first": 119417600,
      "second": 23884300,
      "third": 489700,
      "fourth": 9400,
      "fifth": 1000
    }
  }
]
```

## 12. バッチ詳細設計書

現在はバッチ処理なし。

| バッチID | バッチ名 | 状況 |
|---|---|---|
| なし | なし | 該当なし |

将来追加候補:

| バッチID | バッチ名 | 内容 |
|---|---|---|
| BATCH-001 | ロト6履歴API事前取得バッチ | 外部APIから最新履歴を取得しDBへ保存する |

## 13. エラー処理設計書

| エラーID | 条件 | HTTPステータス | 処理 |
|---|---|---|---|
| ERR-001 | 番号未入力 | 400 | エラーメッセージを返す |
| ERR-002 | 番号数不正 | 400 | エラーメッセージを返す |
| ERR-003 | 数値以外 | 400 | エラーメッセージを返す |
| ERR-004 | 範囲外 | 400 | エラーメッセージを返す |
| ERR-005 | 重複番号 | 400 | エラーメッセージを返す |
| ERR-006 | DB接続エラー | 500 | ログ出力後、システムエラーを返す |
| ERR-007 | 外部API接続エラー | 500 | ログ出力後、外部API取得失敗を返す |
| ERR-999 | 想定外エラー | 500 | ログ出力後、システムエラーを返す |

## 14. ログ出力設計書

| ログID | レベル | タイミング | 出力内容 |
|---|---|---|---|
| LOG-001 | INFO | API開始時 | API名、メソッド |
| LOG-002 | INFO | API正常終了時 | API名、処理時間 |
| LOG-003 | INFO | 外部API取込成功時 | 取込件数、最新開催回 |
| LOG-004 | WARN | 入力不正時 | エラーID、入力値概要 |
| LOG-005 | ERROR | DBエラー時 | エラーID、例外内容 |
| LOG-006 | ERROR | 外部APIエラー時 | エラーID、接続先、例外内容 |
| LOG-999 | ERROR | 想定外エラー時 | エラーID、例外内容 |

## 15. メッセージ一覧

| メッセージID | 種別 | メッセージ |
|---|---|---|
| MSG-E001 | エラー | numbers is required. Example: 2 5 10 23 24 7 |
| MSG-E002 | エラー | Please send exactly 6 numbers separated by spaces. |
| MSG-E003 | エラー | All values must be numbers. |
| MSG-E004 | エラー | Numbers must be between 1 and 43. |
| MSG-E005 | エラー | Duplicate numbers are not allowed. |
| MSG-E006 | エラー | Failed to connect database. |
| MSG-E007 | エラー | Failed to fetch loto6 history from external API. |
| MSG-E999 | エラー | Internal server error. |

## 16. 単体テスト仕様書

### 16.1 Servlet/APIテスト

| テストID | 対象 | 条件 | 期待結果 |
|---|---|---|---|
| UT-001 | 当選チェックAPI | 正常な6数字をGETで送信 | 200、当選結果JSONを返す |
| UT-002 | 当選チェックAPI | 正常な6数字をPOST本文で送信 | 200、当選結果JSONを返す |
| UT-003 | 当選チェックAPI | 3個だけ送信 | 400、MSG-E002を返す |
| UT-004 | 当選チェックAPI | 44を含む | 400、MSG-E004を返す |
| UT-005 | 当選チェックAPI | 重複番号を含む | 400、MSG-E005を返す |
| UT-006 | おすすめ番号API | 正常実行 | 200、6個のおすすめ番号を返す |

### 16.2 Serviceテスト

| テストID | 対象 | 条件 | 期待結果 |
|---|---|---|---|
| UT-101 | 当選判定 | 本数字6個一致 | 1等を返す |
| UT-102 | 当選判定 | 本数字5個一致 + BONUS一致 | 2等を返す |
| UT-103 | 当選判定 | 本数字5個一致 | 3等を返す |
| UT-104 | 当選判定 | 本数字4個一致 | 4等を返す |
| UT-105 | 当選判定 | 本数字3個一致 | 5等を返す |
| UT-106 | おすすめ番号算出 | DBに履歴あり | 6個の番号を返す |

### 16.3 Repository/API Clientテスト

| テストID | 対象 | 条件 | 期待結果 |
|---|---|---|---|
| UT-201 | Repository | 抽選履歴登録 | DBに登録される |
| UT-202 | Repository | 同じ開催回を再登録 | DBが更新される |
| UT-203 | Repository | 抽選履歴取得 | 開催回降順で取得される |
| UT-301 | ApiClient | 外部API正常応答 | 抽選結果モデルへ変換される |
| UT-302 | ApiClient | 外部APIタイムアウト | ERR-007となる |

