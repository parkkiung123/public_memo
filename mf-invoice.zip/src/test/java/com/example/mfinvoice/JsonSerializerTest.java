package com.example.mfinvoice;

import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JsonSerializerTest {

    private final JsonSerializer serializer = new JsonSerializer();

    // ── escapeJson ────────────────────────────────────────────────────────

    @Test
    void escape_doubleQuote() {
        assertEquals("say \\\"hello\\\"", JsonSerializer.escapeJson("say \"hello\""));
    }

    @Test
    void escape_backslash() {
        assertEquals("C:\\\\path", JsonSerializer.escapeJson("C:\\path"));
    }

    @Test
    void escape_newlineAndTab() {
        assertEquals("a\\nb\\tc", JsonSerializer.escapeJson("a\nb\tc"));
    }

    @Test
    void escape_controlChar() {
        assertEquals("\\u0001", JsonSerializer.escapeJson("\u0001"));
    }

    @Test
    void escape_null_returnsEmpty() {
        assertEquals("", JsonSerializer.escapeJson(null));
    }

    // ── taxRateToExcise ───────────────────────────────────────────────────

    @Test
    void taxRate_10percent() {
        assertEquals("ten_percent", JsonSerializer.taxRateToExcise(0.10));
    }

    @Test
    void taxRate_8percent() {
        assertEquals("eight_percent_reduced", JsonSerializer.taxRateToExcise(0.08));
    }

    @Test
    void taxRate_0percent() {
        assertEquals("zero_percent", JsonSerializer.taxRateToExcise(0.0));
    }

    // ── serialize ─────────────────────────────────────────────────────────

    @Test
    void serialize_singleItem() {
        MfInvoiceRequest req = new MfInvoiceRequest(
            "CUST-001",
            "ご請求書 ORD-001",
            "2025-06-01",
            "2025-06-30",
            List.of(new MfInvoiceItem("サービス利用料", 10_000L, 2, 0.10))
        );

        String json = serializer.serialize(req);

        // 必須フィールドが含まれているか
        assertTrue(json.contains("\"partner_code\": \"CUST-001\""),     "partner_code");
        assertTrue(json.contains("\"title\": \"ご請求書 ORD-001\""),    "title");
        assertTrue(json.contains("\"issue_date\": \"2025-06-01\""),      "issue_date");
        assertTrue(json.contains("\"due_date\": \"2025-06-30\""),        "due_date");
        assertTrue(json.contains("\"name\": \"サービス利用料\""),         "item name");
        assertTrue(json.contains("\"unit_price\": 10000"),               "unit_price");
        assertTrue(json.contains("\"quantity\": 2"),                     "quantity");
        assertTrue(json.contains("\"excise\": \"ten_percent\""),         "excise");
    }

    @Test
    void serialize_multipleItems_noTrailingCommaOnLast() {
        MfInvoiceRequest req = new MfInvoiceRequest(
            "C002", "請求書", "2025-07-01", "2025-07-31",
            List.of(
                new MfInvoiceItem("商品A", 1000L, 1, 0.10),
                new MfInvoiceItem("商品B", 2000L, 3, 0.08)
            )
        );

        String json = serializer.serialize(req);

        // 末尾のアイテムの後にカンマが来ないこと（簡易チェック: 最後の } の直前に , がない）
        String trimmed = json.stripTrailing();
        assertFalse(trimmed.endsWith(",}"), "最後のオブジェクトの後にカンマがない");
        assertTrue(json.contains("\"excise\": \"eight_percent_reduced\""), "8%軽減税率");
    }

    @Test
    void serialize_specialCharsInTitle_escaped() {
        MfInvoiceRequest req = new MfInvoiceRequest(
            "C003", "件名に\"引用符\"あり", "2025-08-01", "2025-08-31",
            List.of(new MfInvoiceItem("X", 500L, 1, 0.10))
        );

        String json = serializer.serialize(req);
        assertTrue(json.contains("\\\"引用符\\\""), "ダブルクォートがエスケープされている");
    }
}
