package com.example.mfinvoice;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceConverterTest {

    private final InvoiceConverter converter = new InvoiceConverter();

    private static OrderRow row(int id, String orderNo, String custCode,
                                 String itemName, long price, int qty,
                                 String orderDate, String dueDate, double tax) {
        return new OrderRow(id, orderNo, custCode, "顧客" + custCode,
            LocalDate.parse(orderDate), LocalDate.parse(dueDate),
            itemName, price, qty, tax);
    }

    // ── 基本変換 ──────────────────────────────────────────────────────────

    @Test
    void convert_singleRow_singleInvoice() {
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A", 1000L, 2, "2025-06-01", "2025-06-30", 0.10)
        );

        List<MfInvoiceRequest> result = converter.convert(rows);

        assertEquals(1, result.size());
        MfInvoiceRequest inv = result.get(0);
        assertEquals("C001",       inv.partnerCode());
        assertEquals("2025-06-01", inv.issueDate());
        assertEquals("2025-06-30", inv.dueDate());
        assertEquals(1,            inv.items().size());
        assertEquals("商品A",      inv.items().get(0).name());
    }

    @Test
    void convert_emptyList_returnsEmpty() {
        assertTrue(converter.convert(List.of()).isEmpty());
    }

    // ── グルーピング ───────────────────────────────────────────────────────

    @Test
    void convert_sameCustomer_groupedIntoOneInvoice() {
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A", 1000L, 1, "2025-06-01", "2025-06-30", 0.10),
            row(2, "ORD-001", "C001", "商品B", 2000L, 3, "2025-06-01", "2025-06-30", 0.10)
        );

        List<MfInvoiceRequest> result = converter.convert(rows);

        assertEquals(1, result.size());
        assertEquals(2, result.get(0).items().size());
    }

    @Test
    void convert_differentCustomers_separateInvoices() {
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A", 1000L, 1, "2025-06-01", "2025-06-30", 0.10),
            row(2, "ORD-002", "C002", "商品B", 2000L, 1, "2025-06-05", "2025-07-05", 0.08)
        );

        List<MfInvoiceRequest> result = converter.convert(rows);

        assertEquals(2, result.size());
        assertEquals("C001", result.get(0).partnerCode());
        assertEquals("C002", result.get(1).partnerCode());
    }

    // ── due_date は最も遅い日付を選ぶ ────────────────────────────────────

    @Test
    void convert_latestDueDateChosen() {
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A", 500L, 1, "2025-06-01", "2025-06-15", 0.10),
            row(2, "ORD-001", "C001", "商品B", 500L, 1, "2025-06-01", "2025-06-30", 0.10),
            row(3, "ORD-001", "C001", "商品C", 500L, 1, "2025-06-01", "2025-06-20", 0.10)
        );

        List<MfInvoiceRequest> result = converter.convert(rows);

        assertEquals("2025-06-30", result.get(0).dueDate(), "最も遅い due_date が採用される");
    }

    // ── 登場順の保持 ──────────────────────────────────────────────────────

    @Test
    void convert_preservesInsertionOrder() {
        List<OrderRow> rows = List.of(
            row(1, "ORD-003", "C003", "X", 100L, 1, "2025-06-01", "2025-06-30", 0.10),
            row(2, "ORD-001", "C001", "Y", 100L, 1, "2025-06-01", "2025-06-30", 0.10),
            row(3, "ORD-002", "C002", "Z", 100L, 1, "2025-06-01", "2025-06-30", 0.10)
        );

        List<MfInvoiceRequest> result = converter.convert(rows);

        assertEquals(List.of("C003", "C001", "C002"),
            result.stream().map(MfInvoiceRequest::partnerCode).toList(),
            "customer_code の登場順が保持される");
    }
}
