package com.example.mfinvoice;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JUnit なしで動かせる軽量テストランナー。
 * 外部ライブラリが使えない環境での動作検証用。
 */
public class SelfTest {

    private static int passed = 0;
    private static int failed = 0;
    private static final List<String> failures = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("=== SelfTest 開始 ===\n");

        testEscapeJson();
        testTaxRateToExcise();
        testSerializeSingleItem();
        testSerializeMultiItems();
        testSerializeSpecialChars();
        testConvertEmpty();
        testConvertSingleRow();
        testConvertGrouping();
        testConvertSeparateCustomers();
        testConvertLatestDueDate();
        testConvertPreservesOrder();

        System.out.printf("%n=== 結果: %d 件成功 / %d 件失敗 ===%n", passed, failed);
        if (!failures.isEmpty()) {
            System.out.println("\n失敗一覧:");
            failures.forEach(f -> System.out.println("  ✗ " + f));
            System.exit(1);
        }
        System.out.println("全テスト通過 〇");
    }

    // ── JsonSerializer: escapeJson ─────────────────────────────────────

    static void testEscapeJson() {
        assertEqual("escape doubleQuote",
            "say \\\"hello\\\"", JsonSerializer.escapeJson("say \"hello\""));
        assertEqual("escape backslash",
            "C:\\\\path", JsonSerializer.escapeJson("C:\\path"));
        assertEqual("escape newline and tab",
            "a\\nb\\tc", JsonSerializer.escapeJson("a\nb\tc"));
        assertEqual("escape control char",
            "\\u0001", JsonSerializer.escapeJson("\u0001"));
        assertEqual("escape null returns empty",
            "", JsonSerializer.escapeJson(null));
    }

    // ── JsonSerializer: taxRateToExcise ───────────────────────────────

    static void testTaxRateToExcise() {
        assertEqual("10% -> ten_percent",
            "ten_percent", JsonSerializer.taxRateToExcise(0.10));
        assertEqual("8% -> eight_percent_reduced",
            "eight_percent_reduced", JsonSerializer.taxRateToExcise(0.08));
        assertEqual("0% -> zero_percent",
            "zero_percent", JsonSerializer.taxRateToExcise(0.00));
    }

    // ── JsonSerializer: serialize ─────────────────────────────────────

    static void testSerializeSingleItem() {
        JsonSerializer s = new JsonSerializer();
        MfInvoiceRequest req = new MfInvoiceRequest(
            "CUST-001", "ご請求書 ORD-001", "2025-06-01", "2025-06-30",
            List.of(new MfInvoiceItem("サービス利用料", 10_000L, 2, 0.10))
        );
        String json = s.serialize(req);

        assertContains("partner_code in JSON", json, "\"partner_code\": \"CUST-001\"");
        assertContains("title in JSON",        json, "\"title\": \"ご請求書 ORD-001\"");
        assertContains("issue_date in JSON",   json, "\"issue_date\": \"2025-06-01\"");
        assertContains("due_date in JSON",     json, "\"due_date\": \"2025-06-30\"");
        assertContains("item name in JSON",    json, "\"name\": \"サービス利用料\"");
        assertContains("unit_price in JSON",   json, "\"unit_price\": 10000");
        assertContains("quantity in JSON",     json, "\"quantity\": 2");
        assertContains("excise in JSON",       json, "\"excise\": \"ten_percent\"");
    }

    static void testSerializeMultiItems() {
        JsonSerializer s = new JsonSerializer();
        MfInvoiceRequest req = new MfInvoiceRequest(
            "C002", "請求書", "2025-07-01", "2025-07-31",
            List.of(
                new MfInvoiceItem("商品A", 1000L, 1, 0.10),
                new MfInvoiceItem("商品B", 2000L, 3, 0.08)
            )
        );
        String json = s.serialize(req);
        assertContains("eight_percent_reduced in JSON", json, "\"excise\": \"eight_percent_reduced\"");
        // 末尾が },} のようなパターンがないこと
        assertNotContains("no trailing comma before closing brace", json, ",\n    ]\n");
    }

    static void testSerializeSpecialChars() {
        JsonSerializer s = new JsonSerializer();
        MfInvoiceRequest req = new MfInvoiceRequest(
            "C003", "件名に\"引用符\"あり", "2025-08-01", "2025-08-31",
            List.of(new MfInvoiceItem("X", 500L, 1, 0.10))
        );
        String json = s.serialize(req);
        assertContains("escaped quotes in title", json, "\\\"引用符\\\"");
    }

    // ── InvoiceConverter ─────────────────────────────────────────────

    static void testConvertEmpty() {
        InvoiceConverter c = new InvoiceConverter();
        assertTrue("empty input -> empty output", c.convert(List.of()).isEmpty());
    }

    static void testConvertSingleRow() {
        InvoiceConverter c = new InvoiceConverter();
        List<MfInvoiceRequest> result = c.convert(List.of(row(1, "ORD-001", "C001", "商品A")));
        assertEqual("single row -> 1 invoice", 1, result.size());
        assertEqual("partnerCode", "C001", result.get(0).partnerCode());
        assertEqual("items size",  1,       result.get(0).items().size());
    }

    static void testConvertGrouping() {
        InvoiceConverter c = new InvoiceConverter();
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A"),
            row(2, "ORD-001", "C001", "商品B")
        );
        List<MfInvoiceRequest> result = c.convert(rows);
        assertEqual("2 rows same customer -> 1 invoice", 1, result.size());
        assertEqual("2 items in invoice",               2, result.get(0).items().size());
    }

    static void testConvertSeparateCustomers() {
        InvoiceConverter c = new InvoiceConverter();
        List<OrderRow> rows = List.of(
            row(1, "ORD-001", "C001", "商品A"),
            row(2, "ORD-002", "C002", "商品B")
        );
        List<MfInvoiceRequest> result = c.convert(rows);
        assertEqual("2 customers -> 2 invoices", 2, result.size());
        assertEqual("first partner",  "C001", result.get(0).partnerCode());
        assertEqual("second partner", "C002", result.get(1).partnerCode());
    }

    static void testConvertLatestDueDate() {
        InvoiceConverter c = new InvoiceConverter();
        List<OrderRow> rows = List.of(
            rowWithDue(1, "C001", "2025-06-15"),
            rowWithDue(2, "C001", "2025-06-30"),
            rowWithDue(3, "C001", "2025-06-20")
        );
        List<MfInvoiceRequest> result = c.convert(rows);
        assertEqual("latest due_date chosen", "2025-06-30", result.get(0).dueDate());
    }

    static void testConvertPreservesOrder() {
        InvoiceConverter c = new InvoiceConverter();
        List<OrderRow> rows = List.of(
            row(1, "ORD-003", "C003", "X"),
            row(2, "ORD-001", "C001", "Y"),
            row(3, "ORD-002", "C002", "Z")
        );
        List<MfInvoiceRequest> result = c.convert(rows);
        List<String> codes = result.stream().map(MfInvoiceRequest::partnerCode).toList();
        assertEqual("order preserved", List.of("C003", "C001", "C002"), codes);
    }

    // ── ヘルパー ──────────────────────────────────────────────────────

    private static OrderRow row(int id, String orderNo, String custCode, String itemName) {
        return new OrderRow(id, orderNo, custCode, "顧客" + custCode,
            LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 30),
            itemName, 1000L, 1, 0.10);
    }

    private static OrderRow rowWithDue(int id, String custCode, String due) {
        return new OrderRow(id, "ORD", custCode, "顧客",
            LocalDate.of(2025, 6, 1), LocalDate.parse(due),
            "商品", 1000L, 1, 0.10);
    }

    private static void assertEqual(String name, Object expected, Object actual) {
        if (expected.equals(actual)) {
            System.out.printf("  〇 %s%n", name);
            passed++;
        } else {
            System.err.printf("  ✗ %s: expected=%s actual=%s%n", name, expected, actual);
            failures.add("%s: expected=%s actual=%s".formatted(name, expected, actual));
            failed++;
        }
    }

    private static void assertTrue(String name, boolean cond) {
        if (cond) {
            System.out.printf("  〇 %s%n", name);
            passed++;
        } else {
            System.err.printf("  ✗ %s: expected true%n", name);
            failures.add(name + ": expected true");
            failed++;
        }
    }

    private static void assertContains(String name, String haystack, String needle) {
        if (haystack.contains(needle)) {
            System.out.printf("  〇 %s%n", name);
            passed++;
        } else {
            System.err.printf("  ✗ %s: '%s' not found in output%n", name, needle);
            failures.add("%s: '%s' not found".formatted(name, needle));
            failed++;
        }
    }

    private static void assertNotContains(String name, String haystack, String needle) {
        if (!haystack.contains(needle)) {
            System.out.printf("  〇 %s%n", name);
            passed++;
        } else {
            System.err.printf("  ✗ %s: '%s' should NOT be found%n", name, needle);
            failures.add("%s: '%s' should not exist".formatted(name, needle));
            failed++;
        }
    }
}
