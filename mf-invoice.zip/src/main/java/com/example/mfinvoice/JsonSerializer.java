package com.example.mfinvoice;

import java.util.List;

/**
 * Pure Java（外部ライブラリなし）で MfInvoiceRequest を JSON 文字列へシリアライズする。
 * <p>
 * MF Cloud 請求書 API のリクエストボディ仕様:
 * <pre>
 * {
 *   "invoice": {
 *     "partner_code": "...",
 *     "title": "...",
 *     "issue_date": "yyyy-MM-dd",
 *     "due_date": "yyyy-MM-dd",
 *     "invoice_contents": [
 *       {
 *         "name": "...",
 *         "unit_price": 10000,
 *         "quantity": 1,
 *         "excise": "ten_percent"
 *       }
 *     ]
 *   }
 * }
 * </pre>
 */
public class JsonSerializer {

    /**
     * MfInvoiceRequest を JSON 文字列に変換する。
     */
    public String serialize(MfInvoiceRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"invoice\": {\n");

        appendString(sb, 4, "partner_code", req.partnerCode(), true);
        appendString(sb, 4, "title",        req.title(),       true);
        appendString(sb, 4, "issue_date",   req.issueDate(),   true);
        appendString(sb, 4, "due_date",     req.dueDate(),     true);

        sb.append("    \"invoice_contents\": [\n");
        List<MfInvoiceItem> items = req.items();
        for (int i = 0; i < items.size(); i++) {
            boolean isLast = (i == items.size() - 1);
            appendItem(sb, items.get(i), isLast);
        }
        sb.append("    ]\n");
        sb.append("  }\n");
        sb.append("}");
        return sb.toString();
    }

    // ── private helpers ──────────────────────────────────────────────────────

    private void appendItem(StringBuilder sb, MfInvoiceItem item, boolean isLast) {
        sb.append("      {\n");
        appendString(sb, 8, "name",       item.name(),                      true);
        appendLong  (sb, 8, "unit_price", item.unitPrice(),                  true);
        appendInt   (sb, 8, "quantity",   item.quantity(),                   true);
        appendString(sb, 8, "excise",     taxRateToExcise(item.taxRate()),    false);
        sb.append("      }").append(isLast ? "\n" : ",\n");
    }

    private void appendString(StringBuilder sb, int indent, String key, String value, boolean trailingComma) {
        sb.append(" ".repeat(indent))
          .append("\"").append(key).append("\": ")
          .append("\"").append(escapeJson(value)).append("\"")
          .append(trailingComma ? "," : "")
          .append("\n");
    }

    private void appendLong(StringBuilder sb, int indent, String key, long value, boolean trailingComma) {
        sb.append(" ".repeat(indent))
          .append("\"").append(key).append("\": ")
          .append(value)
          .append(trailingComma ? "," : "")
          .append("\n");
    }

    private void appendInt(StringBuilder sb, int indent, String key, int value, boolean trailingComma) {
        sb.append(" ".repeat(indent))
          .append("\"").append(key).append("\": ")
          .append(value)
          .append(trailingComma ? "," : "")
          .append("\n");
    }

    /**
     * MF Cloud API の excise（税区分）コードへ変換する。
     *
     * @see <a href="https://invoice.moneyforward.com/docs/api/v3">MF Cloud API ドキュメント</a>
     */
    static String taxRateToExcise(double rate) {
        if (rate >= 0.10) return "ten_percent";
        if (rate >= 0.08) return "eight_percent_reduced";
        return "zero_percent";
    }

    /**
     * JSON 文字列値に含まれる制御文字・特殊文字をエスケープする。
     */
    static String escapeJson(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"'  -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default   -> {
                    // U+0000〜U+001F はユニコードエスケープ
                    if (c < 0x20) {
                        sb.append("\\u%04x".formatted((int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }
}
