package com.example.mfinvoice;

import java.util.List;

/**
 * MF Cloud API に POST する請求書1件分
 */
public record MfInvoiceRequest(
    String              partnerCode,
    String              title,
    String              issueDate,   // "yyyy-MM-dd"
    String              dueDate,     // "yyyy-MM-dd"
    List<MfInvoiceItem> items
) {}
