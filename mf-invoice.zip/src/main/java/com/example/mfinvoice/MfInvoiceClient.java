package com.example.mfinvoice;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * MoneyForward クラウド請求書 API クライアント。
 * <p>
 * 使用エンドポイント: POST /api/v3/tokens/invoices
 */
public class MfInvoiceClient {

    private static final String BASE_URL =
        "https://invoice.moneyforward.com/api/v3/tokens/invoices";

    /** タイムアウト（秒） */
    private static final int TIMEOUT_SECONDS = 30;

    private final HttpClient http;
    private final String     accessToken;
    private final JsonSerializer serializer;

    public MfInvoiceClient(String accessToken) {
        this.accessToken = accessToken;
        this.serializer  = new JsonSerializer();
        this.http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(TIMEOUT_SECONDS))
            .build();
    }

    /**
     * 請求書を MF Cloud API へ POST する。
     *
     * @param req 請求書リクエスト
     * @return API レスポンス本文（JSON 文字列）
     * @throws MfApiException HTTP エラー（4xx / 5xx）の場合
     */
    public String postInvoice(MfInvoiceRequest req) throws Exception {
        String json = serializer.serialize(req);

        HttpRequest httpReq = HttpRequest.newBuilder()
            .uri(URI.create(BASE_URL))
            .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
            .header("Content-Type",  "application/json")
            .header("Authorization", "Bearer " + accessToken)
            .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
            .build();

        HttpResponse<String> resp = http.send(httpReq, HttpResponse.BodyHandlers.ofString());

        if (resp.statusCode() >= 400) {
            throw new MfApiException(resp.statusCode(), resp.body(), json);
        }

        return resp.body();
    }

    // ── 例外クラス ────────────────────────────────────────────────────────

    public static class MfApiException extends RuntimeException {
        private final int    statusCode;
        private final String responseBody;
        private final String requestJson;

        public MfApiException(int statusCode, String responseBody, String requestJson) {
            super("MF API error: status=%d body=%s".formatted(statusCode, responseBody));
            this.statusCode   = statusCode;
            this.responseBody = responseBody;
            this.requestJson  = requestJson;
        }

        public int    getStatusCode()   { return statusCode; }
        public String getResponseBody() { return responseBody; }
        public String getRequestJson()  { return requestJson; }
    }
}
