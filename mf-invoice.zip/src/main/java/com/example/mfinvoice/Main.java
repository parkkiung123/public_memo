package com.example.mfinvoice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

/**
 * エントリポイント。
 * <p>
 * 実行に必要な環境変数:
 * <ul>
 *   <li>{@code DB_URL}      — 例: jdbc:postgresql://localhost:5432/mydb</li>
 *   <li>{@code DB_USER}     — DBユーザー名</li>
 *   <li>{@code DB_PASSWORD} — DBパスワード</li>
 *   <li>{@code MF_TOKEN}    — MoneyForward API アクセストークン</li>
 * </ul>
 */
public class Main {

    public static void main(String[] args) throws Exception {

        // ── 設定 ─────────────────────────────────────────────────────────
        String dbUrl      = getEnv("DB_URL",      "jdbc:postgresql://localhost:5432/mydb");
        String dbUser     = getEnv("DB_USER",      "app_user");
        String dbPassword = requireEnv("DB_PASSWORD");
        String mfToken    = requireEnv("MF_TOKEN");

        // ── 処理 ─────────────────────────────────────────────────────────
        InvoiceConverter converter = new InvoiceConverter();
        MfInvoiceClient  client    = new MfInvoiceClient(mfToken);

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {

            // 1. DB から未請求（approved）の注文を取得
            OrderRepository repo = new OrderRepository(conn);
            List<OrderRow> orders = repo.findByStatus("approved");
            System.out.printf("取得件数: %d 行%n", orders.size());

            if (orders.isEmpty()) {
                System.out.println("対象データなし。終了します。");
                return;
            }

            // 2. customer_code 単位でまとめて MfInvoiceRequest に変換
            List<MfInvoiceRequest> invoices = converter.convert(orders);
            System.out.printf("請求書件数: %d 件%n", invoices.size());

            // 3. 各請求書を MF Cloud API へ POST
            int success = 0;
            int failure = 0;
            for (MfInvoiceRequest inv : invoices) {
                try {
                    String respBody = client.postInvoice(inv);
                    System.out.printf("[OK] partner=%s  response=%s%n",
                        inv.partnerCode(), respBody);
                    success++;
                } catch (MfInvoiceClient.MfApiException e) {
                    System.err.printf("[NG] partner=%s  status=%d  body=%s%n",
                        inv.partnerCode(), e.getStatusCode(), e.getResponseBody());
                    failure++;
                    // 1件失敗しても残りを続行する。全件失敗扱いにしたければ rethrow。
                }
            }

            System.out.printf("完了: 成功=%d 失敗=%d%n", success, failure);
            if (failure > 0) {
                System.exit(1); // CI/CD でエラー検知できるよう非ゼロ終了
            }
        }
    }

    private static String getEnv(String key, String defaultValue) {
        String v = System.getenv(key);
        return (v != null && !v.isBlank()) ? v : defaultValue;
    }

    private static String requireEnv(String key) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) {
            throw new IllegalStateException("環境変数 %s が未設定です".formatted(key));
        }
        return v;
    }
}
