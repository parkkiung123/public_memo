package com.example.mfinvoice;

import java.time.LocalDate;

/**
 * ordersテーブルの1行を表すレコード
 */
public record OrderRow(
    int       id,
    String    orderNo,
    String    customerCode,
    String    customerName,
    LocalDate orderDate,
    LocalDate dueDate,
    String    itemName,
    long      unitPrice,
    int       quantity,
    double    taxRate        // 0.10 / 0.08 など
) {}
