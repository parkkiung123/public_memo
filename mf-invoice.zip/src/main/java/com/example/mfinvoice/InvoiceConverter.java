package com.example.mfinvoice;

import java.util.*;

/**
 * OrderRow のリストを MfInvoiceRequest のリストへ変換する。
 * <p>
 * 変換ルール:
 * <ul>
 *   <li>同一 customer_code の行を 1 つの請求書にまとめる</li>
 *   <li>issue_date は同一グループの最初の order_date を使用</li>
 *   <li>due_date は同一グループの最も遅い due_date を使用</li>
 * </ul>
 */
public class InvoiceConverter {

    /**
     * OrderRow リストを customer_code 単位でまとめ、MfInvoiceRequest に変換する。
     *
     * @param rows DB から取得した注文行
     * @return 請求書リクエストのリスト（customer_code の登場順）
     */
    public List<MfInvoiceRequest> convert(List<OrderRow> rows) {
        // customer_code → OrderRow リスト（登場順を保持）
        LinkedHashMap<String, List<OrderRow>> grouped = new LinkedHashMap<>();
        for (OrderRow r : rows) {
            grouped.computeIfAbsent(r.customerCode(), k -> new ArrayList<>()).add(r);
        }

        List<MfInvoiceRequest> requests = new ArrayList<>();
        for (Map.Entry<String, List<OrderRow>> entry : grouped.entrySet()) {
            requests.add(toRequest(entry.getValue()));
        }
        return requests;
    }

    // ── private ─────────────────────────────────────────────────────────────

    private MfInvoiceRequest toRequest(List<OrderRow> group) {
        OrderRow first = group.get(0);

        // 同一グループで最も遅い due_date を採用
        String latestDueDate = group.stream()
            .map(OrderRow::dueDate)
            .max(Comparator.naturalOrder())
            .orElse(first.dueDate())
            .toString();

        List<MfInvoiceItem> items = group.stream()
            .map(r -> new MfInvoiceItem(
                r.itemName(),
                r.unitPrice(),
                r.quantity(),
                r.taxRate()))
            .toList();

        return new MfInvoiceRequest(
            first.customerCode(),
            buildTitle(first),
            first.orderDate().toString(),   // issue_date
            latestDueDate,
            items
        );
    }

    private String buildTitle(OrderRow first) {
        return "ご請求書 " + first.orderNo();
    }
}
