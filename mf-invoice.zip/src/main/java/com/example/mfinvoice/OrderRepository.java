package com.example.mfinvoice;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * orders テーブルから OrderRow を取得するリポジトリ
 */
public class OrderRepository {

    private final Connection conn;

    public OrderRepository(Connection conn) {
        this.conn = conn;
    }

    /**
     * 指定ステータスの注文を取得する。
     * 同一 customer_code の明細がまとめて返るよう ORDER BY を指定。
     *
     * @param status  例: "approved"
     * @return OrderRow のリスト（customer_code, order_date 順）
     */
    public List<OrderRow> findByStatus(String status) throws SQLException {
        String sql = """
                SELECT id,
                       order_no,
                       customer_code,
                       customer_name,
                       order_date,
                       due_date,
                       item_name,
                       unit_price,
                       quantity,
                       tax_rate
                  FROM orders
                 WHERE status = ?
                 ORDER BY customer_code, order_date, id
                """;

        List<OrderRow> rows = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(map(rs));
                }
            }
        }
        return rows;
    }

    /**
     * 複数ステータスを IN 句で絞り込む場合の例
     *
     * @param statuses 例: List.of("approved", "pending")
     */
    public List<OrderRow> findByStatuses(List<String> statuses) throws SQLException {
        if (statuses == null || statuses.isEmpty()) {
            return List.of();
        }

        String placeholders = "?,".repeat(statuses.size());
        placeholders = placeholders.substring(0, placeholders.length() - 1); // 末尾 "," を除去

        String sql = """
                SELECT id,
                       order_no,
                       customer_code,
                       customer_name,
                       order_date,
                       due_date,
                       item_name,
                       unit_price,
                       quantity,
                       tax_rate
                  FROM orders
                 WHERE status IN (%s)
                 ORDER BY customer_code, order_date, id
                """.formatted(placeholders);

        List<OrderRow> rows = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < statuses.size(); i++) {
                ps.setString(i + 1, statuses.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(map(rs));
                }
            }
        }
        return rows;
    }

    // ── private ─────────────────────────────────────────────────────────────

    private static OrderRow map(ResultSet rs) throws SQLException {
        return new OrderRow(
            rs.getInt("id"),
            rs.getString("order_no"),
            rs.getString("customer_code"),
            rs.getString("customer_name"),
            rs.getDate("order_date").toLocalDate(),
            rs.getDate("due_date").toLocalDate(),
            rs.getString("item_name"),
            rs.getLong("unit_price"),
            rs.getInt("quantity"),
            rs.getDouble("tax_rate")
        );
    }
}
