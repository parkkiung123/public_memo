package com.example.mfinvoice;

import java.util.List;

/**
 * MF Cloud API に送る請求書明細1行
 */
public record MfInvoiceItem(
    String name,
    long   unitPrice,
    int    quantity,
    double taxRate
) {}
