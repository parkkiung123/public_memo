# schema.sqlのordersのテーブル名が重複するので
# 既存のordersテーブルをbackup_orders.sqlにバックアップした

# ビルド
mvn package

# 実行（環境変数で認証情報を渡す）
export DB_URL=jdbc:postgresql://localhost:5432/mydb
export DB_USER=app_user
export DB_PASSWORD=xxxxx
export MF_TOKEN=your_mf_access_token

java -jar target/mf-invoice.jar