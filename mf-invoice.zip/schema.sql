-- ============================================================
-- DDL
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
    id            SERIAL         PRIMARY KEY,
    order_no      VARCHAR(50)    NOT NULL,
    customer_code VARCHAR(50)    NOT NULL,
    customer_name VARCHAR(200)   NOT NULL,
    order_date    DATE           NOT NULL,
    due_date      DATE           NOT NULL,
    item_name     VARCHAR(200)   NOT NULL,
    unit_price    NUMERIC(12, 0) NOT NULL,
    quantity      INT            NOT NULL DEFAULT 1,
    tax_rate      NUMERIC(5, 2)  NOT NULL DEFAULT 0.10,
    status        VARCHAR(20)    NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft', 'approved', 'invoiced', 'cancelled')),
    created_at    TIMESTAMPTZ    NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ    NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders (customer_code, order_date);

-- ============================================================
-- サンプルデータ（approved = 請求対象）
-- ============================================================
INSERT INTO orders
    (order_no, customer_code, customer_name, order_date, due_date,
     item_name, unit_price, quantity, tax_rate, status)
VALUES
-- 顧客 C001: 2明細
('ORD-2025-0001', 'C001', '株式会社サンプル',
 '2025-06-01', '2025-06-30',
 'クラウドストレージ利用料（月額）', 10000, 3, 0.10, 'approved'),
('ORD-2025-0001', 'C001', '株式会社サンプル',
 '2025-06-01', '2025-06-30',
 'サポートオプション（月額）',        5000, 1, 0.10, 'approved'),

-- 顧客 C002: 軽減税率あり
('ORD-2025-0002', 'C002', 'テスト商事株式会社',
 '2025-06-05', '2025-07-05',
 '食品サンプルセット（軽減税率8%）',  3000, 10, 0.08, 'approved'),

-- 顧客 C003: ゼロ税率
('ORD-2025-0003', 'C003', '海外取引先 Inc.',
 '2025-06-10', '2025-07-10',
 '海外向けコンサルティング（非課税）', 200000, 1, 0.00, 'approved'),

-- draft（対象外）
('ORD-2025-0004', 'C001', '株式会社サンプル',
 '2025-06-15', '2025-07-15',
 '翌月分予約明細', 8000, 2, 0.10, 'draft');
