--
-- PostgreSQL database dump
--

\restrict AdIYas9nlYnh8NkQvBUL8r6eKiQ0amx4gLclN5eUMy0VErokYinpRxN7y5duOW6

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

-- Started on 2026-05-18 15:35:13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 228 (class 1259 OID 16793)
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    ordered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(20) NOT NULL,
    shipping_fee numeric(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT orders_shipping_fee_check CHECK ((shipping_fee >= (0)::numeric)),
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'shipped'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16792)
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.orders ALTER COLUMN order_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 5036 (class 0 OID 16793)
-- Dependencies: 228
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, customer_id, ordered_at, status, shipping_fee) FROM stdin;
1	1	2026-04-01 10:15:00	paid	500.00
2	1	2026-04-15 19:40:00	shipped	0.00
3	2	2026-04-03 12:05:00	shipped	500.00
4	3	2026-04-05 09:30:00	cancelled	0.00
5	3	2026-04-21 14:20:00	paid	500.00
6	5	2026-04-25 16:45:00	pending	500.00
7	6	2026-05-02 11:10:00	paid	0.00
\.


--
-- TOC entry 5042 (class 0 OID 0)
-- Dependencies: 227
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 7, true);


--
-- TOC entry 4886 (class 2606 OID 16806)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- TOC entry 4883 (class 1259 OID 16835)
-- Name: idx_orders_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_customer_id ON public.orders USING btree (customer_id);


--
-- TOC entry 4884 (class 1259 OID 16836)
-- Name: idx_orders_ordered_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_ordered_at ON public.orders USING btree (ordered_at);


--
-- TOC entry 4887 (class 2606 OID 16807)
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


-- Completed on 2026-05-18 15:35:13

--
-- PostgreSQL database dump complete
--

\unrestrict AdIYas9nlYnh8NkQvBUL8r6eKiQ0amx4gLclN5eUMy0VErokYinpRxN7y5duOW6

