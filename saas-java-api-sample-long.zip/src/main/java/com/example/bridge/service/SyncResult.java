package com.example.bridge.service;

import java.util.ArrayList;
import java.util.List;

public class SyncResult {
    private final List<String> messages = new ArrayList<>();

    public void addSuccess(String purchaseId, String voucherId, String accountingResponseId) {
        messages.add("purchase=" + purchaseId + ", voucher=" + voucherId + ", accountingResponse=" + accountingResponseId);
    }

    public String toDisplayText() {
        StringBuilder builder = new StringBuilder();
        builder.append("連携完了: ").append(messages.size()).append("件").append(System.lineSeparator());
        for (String message : messages) {
            builder.append(" - ").append(message).append(System.lineSeparator());
        }
        return builder.toString();
    }
}
