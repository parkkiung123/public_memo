package com.example.bridge.service;

import com.example.bridge.model.AccountingVoucher;
import com.example.bridge.model.ProcurementRecord;

import java.time.LocalDate;

public class MappingService {
    public AccountingVoucher toVoucher(ProcurementRecord purchase) {
        String debitAccount = resolveExpenseAccount(purchase.departmentCode(), purchase.itemName());
        String voucherId = "V-" + purchase.purchaseId();
        return new AccountingVoucher(
                voucherId,
                purchase.purchaseId(),
                debitAccount,
                "2000",
                purchase.amount(),
                LocalDate.now()
        );
    }

    private String resolveExpenseAccount(String departmentCode, String itemName) {
        if (itemName.contains("PC")) {
            return "8420";
        }
        if (departmentCode.startsWith("D-01")) {
            return "8310";
        }
        return "8390";
    }
}
