package com.example.bridge.accounting;

import com.example.bridge.config.AppConfig;
import com.example.bridge.model.AccountingVoucher;
import com.example.bridge.util.JsonUtil;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class AccountingClient {
    private final AppConfig config;

    public AccountingClient(AppConfig config) {
        this.config = config;
    }

    public String postVoucher(AccountingVoucher voucher) {
        if (config.accountingEndpoint().startsWith("sample://")) {
            return "SAMPLE-" + voucher.voucherId();
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(config.accountingEndpoint() + "/vouchers"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(JsonUtil.toJson(voucher)))
                .build();
        try {
            return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString()).body();
        } catch (IOException e) {
            throw new IllegalStateException("経理SaaS APIへの接続に失敗しました", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("経理SaaS APIの呼び出しが中断されました", e);
        }
    }
}
