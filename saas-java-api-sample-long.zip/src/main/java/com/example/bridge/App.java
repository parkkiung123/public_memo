package com.example.bridge;

import com.example.bridge.accounting.AccountingClient;
import com.example.bridge.config.AppConfig;
import com.example.bridge.db.Db;
import com.example.bridge.procurement.ProcurementClient;
import com.example.bridge.service.BridgeService;
import com.example.bridge.service.MappingService;
import com.example.bridge.service.SyncResult;

public class App {
    public static void main(String[] args) {
        AppConfig config = AppConfig.fromEnvironment();
        BridgeService service = new BridgeService(
                new ProcurementClient(config),
                new AccountingClient(config),
                new MappingService(),
                new Db(config)
        );

        SyncResult result = service.syncDailyPurchases();
        System.out.println(result.toDisplayText());
    }
}
