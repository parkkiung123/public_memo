package com.example.bridge.config;

public class AppConfig {
    private final String procurementEndpoint;
    private final String accountingEndpoint;
    private final String dbUrl;
    private final String dbUser;
    private final String dbPassword;

    private AppConfig(String procurementEndpoint, String accountingEndpoint, String dbUrl, String dbUser, String dbPassword) {
        this.procurementEndpoint = procurementEndpoint;
        this.accountingEndpoint = accountingEndpoint;
        this.dbUrl = dbUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }

    public static AppConfig fromEnvironment() {
        return new AppConfig(
                env("PROCUREMENT_API_URL", "sample://procurement"),
                env("ACCOUNTING_API_URL", "sample://accounting"),
                env("BRIDGE_DB_URL", ""),
                env("BRIDGE_DB_USER", ""),
                env("BRIDGE_DB_PASSWORD", "")
        );
    }

    private static String env(String name, String defaultValue) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? defaultValue : value;
    }

    public String procurementEndpoint() {
        return procurementEndpoint;
    }

    public String accountingEndpoint() {
        return accountingEndpoint;
    }

    public boolean dbEnabled() {
        return !dbUrl.isBlank();
    }

    public String dbUrl() {
        return dbUrl;
    }

    public String dbUser() {
        return dbUser;
    }

    public String dbPassword() {
        return dbPassword;
    }
}
