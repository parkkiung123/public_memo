package com.example.bridge.procurement;

import com.example.bridge.config.AppConfig;
import com.example.bridge.model.ProcurementRecord;
import com.example.bridge.util.JsonUtil;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class ProcurementClient {
    private final AppConfig config;

    public ProcurementClient(AppConfig config) {
        this.config = config;
    }

    public List<ProcurementRecord> fetchDailyPurchases() {
        if (config.procurementEndpoint().startsWith("sample://")) {
            return sampleRecords();
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(config.procurementEndpoint() + "/purchases/daily"))
                .header("Accept", "application/json")
                .GET()
                .build();
        try {
            String body = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString()).body();
            return JsonUtil.parsePurchaseArray(body);
        } catch (IOException e) {
            throw new IllegalStateException("間接材システムAPIへの接続に失敗しました", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("間接材システムAPIの呼び出しが中断されました", e);
        }
    }

    private List<ProcurementRecord> sampleRecords() {
        return Arrays.asList(
                new ProcurementRecord("P-1001", "SUP-001", "D-010", "コピー用紙", new BigDecimal("12800"), LocalDate.now()),
                new ProcurementRecord("P-1002", "SUP-002", "D-020", "PC周辺機器", new BigDecimal("45800"), LocalDate.now())
        );
    }
}
