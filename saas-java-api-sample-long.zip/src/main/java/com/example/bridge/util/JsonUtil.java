package com.example.bridge.util;

import com.example.bridge.model.AccountingVoucher;
import com.example.bridge.model.ProcurementRecord;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class JsonUtil {
    private JsonUtil() {
    }

    public static String toJson(AccountingVoucher voucher) {
        return "{"
                + "\"voucherId\":\"" + escape(voucher.voucherId()) + "\","
                + "\"purchaseId\":\"" + escape(voucher.purchaseId()) + "\","
                + "\"debitAccount\":\"" + escape(voucher.debitAccount()) + "\","
                + "\"creditAccount\":\"" + escape(voucher.creditAccount()) + "\","
                + "\"amount\":" + voucher.amount() + ","
                + "\"postedAt\":\"" + voucher.postedAt() + "\""
                + "}";
    }

    public static List<ProcurementRecord> parsePurchaseArray(String body) {
        // 本番では Jackson などのJSONライブラリ利用を想定。ここではサンプルを簡潔に保つため最小パーサです。
        List<ProcurementRecord> records = new ArrayList<>();
        String[] rows = body.replace("[", "").replace("]", "").split("\\},\\{");
        for (String row : rows) {
            String normalized = row.replace("{", "").replace("}", "");
            records.add(new ProcurementRecord(
                    value(normalized, "purchaseId"),
                    value(normalized, "supplierCode"),
                    value(normalized, "departmentCode"),
                    value(normalized, "itemName"),
                    new BigDecimal(value(normalized, "amount")),
                    LocalDate.parse(value(normalized, "purchasedAt"))
            ));
        }
        return records;
    }

    private static String value(String row, String key) {
        String marker = "\"" + key + "\":";
        int start = row.indexOf(marker);
        if (start < 0) {
            return "";
        }
        int valueStart = start + marker.length();
        if (row.charAt(valueStart) == '"') {
            int end = row.indexOf('"', valueStart + 1);
            return row.substring(valueStart + 1, end);
        }
        int end = row.indexOf(',', valueStart);
        return end < 0 ? row.substring(valueStart).trim() : row.substring(valueStart, end).trim();
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
