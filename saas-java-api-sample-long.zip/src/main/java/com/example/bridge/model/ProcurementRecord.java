package com.example.bridge.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ProcurementRecord {
    private final String purchaseId;
    private final String supplierCode;
    private final String departmentCode;
    private final String itemName;
    private final BigDecimal amount;
    private final LocalDate purchasedAt;

    public ProcurementRecord(String purchaseId, String supplierCode, String departmentCode, String itemName, BigDecimal amount, LocalDate purchasedAt) {
        this.purchaseId = purchaseId;
        this.supplierCode = supplierCode;
        this.departmentCode = departmentCode;
        this.itemName = itemName;
        this.amount = amount;
        this.purchasedAt = purchasedAt;
    }

    public String purchaseId() {
        return purchaseId;
    }

    public String supplierCode() {
        return supplierCode;
    }

    public String departmentCode() {
        return departmentCode;
    }

    public String itemName() {
        return itemName;
    }

    public BigDecimal amount() {
        return amount;
    }

    public LocalDate purchasedAt() {
        return purchasedAt;
    }
}
