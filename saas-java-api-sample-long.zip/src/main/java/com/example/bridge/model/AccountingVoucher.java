package com.example.bridge.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AccountingVoucher {
    private final String voucherId;
    private final String purchaseId;
    private final String debitAccount;
    private final String creditAccount;
    private final BigDecimal amount;
    private final LocalDate postedAt;

    public AccountingVoucher(String voucherId, String purchaseId, String debitAccount, String creditAccount, BigDecimal amount, LocalDate postedAt) {
        this.voucherId = voucherId;
        this.purchaseId = purchaseId;
        this.debitAccount = debitAccount;
        this.creditAccount = creditAccount;
        this.amount = amount;
        this.postedAt = postedAt;
    }

    public String voucherId() {
        return voucherId;
    }

    public String purchaseId() {
        return purchaseId;
    }

    public String debitAccount() {
        return debitAccount;
    }

    public String creditAccount() {
        return creditAccount;
    }

    public BigDecimal amount() {
        return amount;
    }

    public LocalDate postedAt() {
        return postedAt;
    }
}
