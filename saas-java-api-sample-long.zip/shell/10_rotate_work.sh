#!/usr/bin/env bash
set -euo pipefail
mkdir -p work/done work/error
find work -maxdepth 1 -type f -mtime +7 -exec mv {} work/done/ \;
