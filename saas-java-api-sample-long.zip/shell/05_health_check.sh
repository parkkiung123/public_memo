#!/usr/bin/env bash
set -euo pipefail
test -f "${APP_JAR:-target/saas-bridge-sample-1.0.0-SNAPSHOT.jar}"
echo "OK"
