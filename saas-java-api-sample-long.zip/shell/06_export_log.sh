#!/usr/bin/env bash
set -euo pipefail
mkdir -p export
cp -R logs "export/logs_$(date '+%Y%m%d%H%M%S')" 2>/dev/null || true
