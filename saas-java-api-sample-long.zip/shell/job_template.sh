#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"
job_name="$(basename "$0" .sh)"
echo "sample operational shell: ${job_name}"
