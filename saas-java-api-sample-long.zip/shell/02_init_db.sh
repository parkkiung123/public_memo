#!/usr/bin/env bash
set -euo pipefail
psql "$BRIDGE_DB_URL" -f db/schema.sql
