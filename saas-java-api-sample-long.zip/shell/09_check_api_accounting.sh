#!/usr/bin/env bash
set -euo pipefail
curl -fsS "${ACCOUNTING_API_URL:-http://localhost:8082}/health"
