#!/usr/bin/env bash
set -euo pipefail
mkdir -p archive
tar -czf "archive/logs_$(date '+%Y%m%d%H%M%S').tar.gz" logs 2>/dev/null || true
