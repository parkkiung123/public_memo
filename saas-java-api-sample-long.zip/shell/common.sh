#!/usr/bin/env bash
set -euo pipefail

APP_JAR="${APP_JAR:-target/saas-bridge-sample-1.0.0-SNAPSHOT.jar}"
LOG_DIR="${LOG_DIR:-logs}"

mkdir -p "$LOG_DIR"

run_bridge() {
  local job_name="$1"
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] start ${job_name}" | tee -a "$LOG_DIR/${job_name}.log"
  java -jar "$APP_JAR" | tee -a "$LOG_DIR/${job_name}.log"
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] end ${job_name}" | tee -a "$LOG_DIR/${job_name}.log"
}
