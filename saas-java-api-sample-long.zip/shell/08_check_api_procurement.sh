#!/usr/bin/env bash
set -euo pipefail
curl -fsS "${PROCUREMENT_API_URL:-http://localhost:8081}/health"
