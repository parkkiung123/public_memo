#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/job_template.sh"
