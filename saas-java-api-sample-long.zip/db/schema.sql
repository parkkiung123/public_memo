create table if not exists bridge_sync_log (
    id bigserial primary key,
    source_system varchar(64) not null,
    source_id varchar(64) not null,
    target_system varchar(64) not null,
    target_id varchar(64),
    status varchar(32) not null,
    message text,
    created_at timestamp not null default current_timestamp
);

create table if not exists procurement_purchase (
    purchase_id varchar(64) primary key,
    supplier_code varchar(64) not null,
    department_code varchar(64) not null,
    item_name varchar(256) not null,
    amount numeric(12, 2) not null,
    purchased_at date not null
);

create table if not exists accounting_voucher (
    voucher_id varchar(64) primary key,
    purchase_id varchar(64) not null references procurement_purchase(purchase_id),
    debit_account varchar(32) not null,
    credit_account varchar(32) not null,
    amount numeric(12, 2) not null,
    posted_at date not null
);
