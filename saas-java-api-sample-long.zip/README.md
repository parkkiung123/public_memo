# 間接材・経理SaaS連携ブリッジ 簡易サンプル

間接材向けシステムから購買データを取得し、勘定科目などを変換して、経理系SaaSへ仕訳として連携するブリッジシステムの最小例です。

## 構成

- Java 11: API取得、変換、DB登録、経理SaaS送信のサンプル実装
- Shell: 日次・再送・監視・保守など、45本規模を想定した運用スクリプト例
- DB: PostgreSQL のテーブル定義

## 実行例

```bash
mvn package
java -jar target/saas-bridge-sample-1.0.0-SNAPSHOT.jar
```

PostgreSQLに接続する場合は、JDBCドライバをクラスパスに追加した上で環境変数を設定します。

```bash
export BRIDGE_DB_URL="jdbc:postgresql://localhost:5432/bridge"
export BRIDGE_DB_USER="bridge"
export BRIDGE_DB_PASSWORD="bridge"
```

このサンプルは外部依存なしでビルドできるよう、APIレスポンスとDB接続は未設定時にサンプル動作へフォールバックします。
