from http.server import HTTPServer, BaseHTTPRequestHandler
import base64
import urllib.parse
import os
import datetime

SAVE_DIR = "captures"
os.makedirs(SAVE_DIR, exist_ok=True)

class SimpleHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/save":
            length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(length).decode("utf-8")

            # フォームデータとして送られてくる場合のパース
            params = urllib.parse.parse_qs(post_data)
            image_data = params.get("image", [None])[0]
            filename = params.get("filename", ["capture.png"])[0]

            if image_data and image_data.startswith("data:image/png;base64,"):
                image_data = image_data.split(",", 1)[1]
                image_bytes = base64.b64decode(image_data)

                # 保存ファイル名
                ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = os.path.join(SAVE_DIR, f"{filename}_{ts}.png")

                with open(save_path, "wb") as f:
                    f.write(image_bytes)

                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"Saved")
            else:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Invalid image data")
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    server = HTTPServer(("localhost", 8000), SimpleHandler)
    print("Server running at http://localhost:8000")
    server.serve_forever()
