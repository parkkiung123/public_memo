import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as dat from 'dat.gui';

// --- Scene
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x808080); // 背景を灰色に

// --- Object A
const objA = new THREE.Mesh(
  new THREE.TorusKnotGeometry(0.5, 0.18, 180, 24),
  new THREE.MeshStandardMaterial({ color: 0xff5533, roughness: 0.4, metalness: 0.2 })
);
scene.add(objA);

// --- Light
const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
dirLight.position.set(1.5, 2, 2.5);
scene.add(dirLight, new THREE.AmbientLight(0xffffff, 0.25));

// --- Camera controls
let cameras = [];
let renderTargets = [];
let screenMeshes = [];

const RT_SIZE = 512;

// GUI パラメータ
const params = {
  cameraCount: 4,
  distance: 2.2,
};

// --- Main view camera
const camView = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 50);
camView.position.set(5, 3.5, 6);
camView.lookAt(0,0,0);

// --- Renderer
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// --- OrbitControls
const controls = new OrbitControls(camView, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.screenSpacePanning = true;

// --- Function to create cameras around Object A
function createCameras() {
  // 古いカメラを削除
  cameras.forEach(cam => scene.remove(cam));
  screenMeshes.forEach(mesh => scene.remove(mesh));
  renderTargets.forEach(rt => rt.dispose());

  cameras = [];
  renderTargets = [];
  screenMeshes = [];

  for(let i=0;i<params.cameraCount;i++){
    const angle = (i / params.cameraCount) * Math.PI * 2;
    const pos = new THREE.Vector3(
      Math.cos(angle) * params.distance,
      0,
      Math.sin(angle) * params.distance
    );

    // カメラ
    const cam = new THREE.PerspectiveCamera(45,1,0.2,6);
    cam.position.copy(pos);
    cam.lookAt(objA.position);
    scene.add(cam);
    cameras.push(cam);

    // RenderTarget
    const rt = new THREE.WebGLRenderTarget(RT_SIZE, RT_SIZE, { depthBuffer:true });
    rt.texture.generateMipmaps = false;
    rt.texture.colorSpace = THREE.SRGBColorSpace;
    renderTargets.push(rt);

    // Screen Mesh
    const screenMat = new THREE.MeshBasicMaterial({ map: rt.texture, side: THREE.DoubleSide });
    const screenMesh = new THREE.Mesh(new THREE.PlaneGeometry(1,1), screenMat);
    screenMesh.layers.set(1);
    scene.add(screenMesh);
    screenMeshes.push(screenMesh);
  }
}

// --- Update screen mesh to camera near plane
function updateScreenAtNearPlane(cam, screenMesh){
  const near = cam.near;
  const h = 2 * near * Math.tan(THREE.MathUtils.degToRad(cam.fov*0.5));
  const w = h * cam.aspect;

  screenMesh.geometry.dispose();
  screenMesh.geometry = new THREE.PlaneGeometry(w,h);

  screenMesh.position.copy(cam.position);
  screenMesh.quaternion.copy(cam.quaternion);
  screenMesh.updateMatrixWorld();
  screenMesh.translateZ(-near-0.001);
}

// 初回生成
createCameras();

// --- GUI
const gui = new dat.GUI();
gui.add(params,'cameraCount',1,12,1).name('Camera Count').onChange(createCameras);
gui.add(params,'distance',0.5,5,0.1).name('Camera Distance').onChange(() => {
  cameras.forEach((cam,idx)=>{
    const angle = (idx / params.cameraCount) * Math.PI * 2;
    cam.position.set(Math.cos(angle)*params.distance,1,Math.sin(angle)*params.distance);
    cam.lookAt(objA.position);
  });
});

function saveRenderTargetToServer(renderTarget, filename) {
  const pixels = new Uint8Array(renderTarget.width * renderTarget.height * 4);
  renderer.readRenderTargetPixels(
    renderTarget,
    0, 0, renderTarget.width, renderTarget.height,
    pixels
  );

  // canvasに転写してPNG化
  const canvas = document.createElement("canvas");
  canvas.width = renderTarget.width;
  canvas.height = renderTarget.height;
  const ctx = canvas.getContext("2d");
  const imageData = ctx.createImageData(renderTarget.width, renderTarget.height);
  imageData.data.set(pixels);
  ctx.putImageData(imageData, 0, 0);

  const dataURL = canvas.toDataURL("image/png");

  // サーバーに送信
  fetch("http://localhost:8000/save", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `image=${encodeURIComponent(dataURL)}&filename=${encodeURIComponent(filename)}`
  }).then(res => res.text()).then(console.log);
}

// --- Animate
let t = 0;
function animate(){
  requestAnimationFrame(animate);
  // t += 0.01;
  // objA.rotation.set(t*0.6,t,0);

  cameras.forEach((cam,idx)=>{
    updateScreenAtNearPlane(cam,screenMeshes[idx]);
    cam.layers.set(0);
    renderer.setRenderTarget(renderTargets[idx]);
    renderer.render(scene,cam);
  });
  renderer.setRenderTarget(null);

  controls.update();
  camView.layers.enable(0);
  camView.layers.enable(1);
  renderer.render(scene,camView);
}
animate();

setInterval(() => {
  cameras.forEach((cam, idx) => {
    saveRenderTargetToServer(renderTargets[idx], `camera_${idx}`);
  });
}, 5000);

// --- Resize
window.addEventListener('resize',()=>{
  camView.aspect = window.innerWidth/window.innerHeight;
  camView.updateProjectionMatrix();
  renderer.setSize(window.innerWidth,window.innerHeight);
});
