package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet({"/hello", "/hello2", "/runShell", "/userList", "/callProc"})
public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String path = req.getServletPath();


         resp.setCharacterEncoding("UTF-8");
       if ("/hello".equals(path)) {

            resp.setContentType("text/html;charset=UTF-8");

            PrintWriter out = resp.getWriter();
            out.println("<h1>Hello Servlet Mav!</h1>");

        } else if ("/hello2".equals(path)) {

            // JSPへ転送
            req.getRequestDispatcher("/index.jsp")
               .forward(req, resp);
        } else if ("/runShell".equals(path)) {
            ProcessBuilder pb = new ProcessBuilder(
                "/bin/bash",
                "/root/java/shell/user_cmd.sh"
            );

            pb.redirectErrorStream(true);
            Process p = pb.start();

            resp.setContentType("text/plain;charset=UTF-8");
            resp.getWriter().println("script executed");
        } else if ("/userList".equals(path)) {
            ProcessBuilder pb = new ProcessBuilder(
                    "bash",
                    "/root/java/shell/postgre_cmd.sh"
            );

            pb.redirectErrorStream(true);
            Process p = pb.start();

            resp.setContentType("text/plain;charset=UTF-8");
            resp.getWriter().println("script executed");
        } else if ("/callProc".equals(path)) {
            ProcessBuilder pb = new ProcessBuilder(
                    "bash",
                    "/root/java/shell/postgre_call_proc.sh"
            );

            pb.redirectErrorStream(true);
            Process p = pb.start();

            resp.setContentType("text/plain;charset=UTF-8");
            resp.getWriter().println("script executed");
        }
    }
}