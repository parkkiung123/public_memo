#!/bin/bash
mv /root/java/temp/aaa.txt /root/java/temp/bbb.txt