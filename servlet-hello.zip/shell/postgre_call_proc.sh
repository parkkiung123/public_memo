#!/bin/bash

# 出力先（不要なら削除OK）
outputFile="/root/java/temp/proc_result.txt"

# PostgreSQL接続情報
dbHost="localhost"
port="5432"
db="testDB"
user="interline"
export PGPASSWORD="interline"

# プロシージャ実行
psql \
  -h "$dbHost" \
  -p "$port" \
  -U "$user" \
  -d "$db" \
  -c "CALL public.insert_random_user();" \
  > "$outputFile"