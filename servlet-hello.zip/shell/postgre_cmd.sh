#!/bin/bash

# 出力ファイル
outputFile="/root/java/temp/users.txt"

# PostgreSQL接続情報
dbHost="localhost"
port="5432"
db="testDB"
user="interline"
export PGPASSWORD="interline"

# SQL実行してCSV出力
psql \
  -h "$dbHost" \
  -p "$port" \
  -U "$user" \
  -d "$db" \
  -c "SELECT id, name, email, created_at FROM users;" \
  -A -F "," > "$outputFile"