package com.example.bridge.service;

import com.example.bridge.accounting.AccountingClient;
import com.example.bridge.db.Db;
import com.example.bridge.model.AccountingVoucher;
import com.example.bridge.model.ProcurementRecord;
import com.example.bridge.procurement.ProcurementClient;

import java.util.List;

public class BridgeService {
    private final ProcurementClient procurementClient;
    private final AccountingClient accountingClient;
    private final MappingService mappingService;
    private final Db db;

    public BridgeService(ProcurementClient procurementClient, AccountingClient accountingClient, MappingService mappingService, Db db) {
        this.procurementClient = procurementClient;
        this.accountingClient = accountingClient;
        this.mappingService = mappingService;
        this.db = db;
    }

    public SyncResult syncDailyPurchases() {
        List<ProcurementRecord> purchases = procurementClient.fetchDailyPurchases();
        SyncResult result = new SyncResult();
        for (ProcurementRecord purchase : purchases) {
            AccountingVoucher voucher = null;
            try {
                db.savePurchase(purchase);
                voucher = mappingService.toVoucher(purchase);
                db.saveVoucher(voucher);
                String responseId = accountingClient.postVoucher(voucher);
                db.saveSyncLog(
                        "PROCUREMENT",
                        purchase.purchaseId(),
                        "ACCOUNTING",
                        voucher.voucherId(),
                        "SUCCESS",
                        "accountingResponse=" + responseId
                );
                result.addSuccess(purchase.purchaseId(), voucher.voucherId(), responseId);
            } catch (RuntimeException e) {
                db.saveSyncLog(
                        "PROCUREMENT",
                        purchase.purchaseId(),
                        "ACCOUNTING",
                        voucher == null ? null : voucher.voucherId(),
                        "ERROR",
                        e.getMessage()
                );
                throw e;
            }
        }
        return result;
    }
}
