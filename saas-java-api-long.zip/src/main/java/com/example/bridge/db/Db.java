package com.example.bridge.db;

import com.example.bridge.config.AppConfig;
import com.example.bridge.model.AccountingVoucher;
import com.example.bridge.model.ProcurementRecord;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Db {
    private final AppConfig config;

    public Db(AppConfig config) {
        this.config = config;
    }

    public void savePurchase(ProcurementRecord record) {
        if (!config.dbEnabled()) {
            return;
        }
        String sql = "insert into procurement_purchase "
                + "(purchase_id, supplier_code, department_code, item_name, amount, purchased_at) "
                + "values (?, ?, ?, ?, ?, ?) "
                + "on conflict (purchase_id) do update set amount = excluded.amount";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, record.purchaseId());
            statement.setString(2, record.supplierCode());
            statement.setString(3, record.departmentCode());
            statement.setString(4, record.itemName());
            statement.setBigDecimal(5, record.amount());
            statement.setObject(6, record.purchasedAt());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("購買データのDB保存に失敗しました: " + record.purchaseId(), e);
        }
    }

    public void saveVoucher(AccountingVoucher voucher) {
        if (!config.dbEnabled()) {
            return;
        }
        String sql = "insert into accounting_voucher "
                + "(voucher_id, purchase_id, debit_account, credit_account, amount, posted_at) "
                + "values (?, ?, ?, ?, ?, ?) "
                + "on conflict (voucher_id) do nothing";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, voucher.voucherId());
            statement.setString(2, voucher.purchaseId());
            statement.setString(3, voucher.debitAccount());
            statement.setString(4, voucher.creditAccount());
            statement.setBigDecimal(5, voucher.amount());
            statement.setObject(6, voucher.postedAt());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("仕訳データのDB保存に失敗しました: " + voucher.voucherId(), e);
        }
    }

    public void saveSyncLog(String sourceSystem, String sourceId, String targetSystem, String targetId, String status, String message) {
        if (!config.dbEnabled()) {
            return;
        }
        String sql = "insert into bridge_sync_log "
                + "(source_system, source_id, target_system, target_id, status, message) "
                + "values (?, ?, ?, ?, ?, ?)";
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, sourceSystem);
            statement.setString(2, sourceId);
            statement.setString(3, targetSystem);
            statement.setString(4, targetId);
            statement.setString(5, status);
            statement.setString(6, message);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("連携ログのDB保存に失敗しました: " + sourceId, e);
        }
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(config.dbUrl(), config.dbUser(), config.dbPassword());
    }
}
