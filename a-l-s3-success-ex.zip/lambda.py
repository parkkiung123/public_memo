import os
import json
import base64
import boto3

s3 = boto3.client("s3")
BUCKET = "xxxx-xxxx-xxxx" 

def lambda_handler(event, context):
    # CORS対応ヘッダ
    cors_headers = {
    "Access-Control-Allow-Origin":"*",
    }

    path_params = event.get("pathParameters") or {}
    map_num = path_params.get("mapNum")
    
    if map_num:
        # 例: mapNum=1 → m1.jpg
        key = f"m{map_num}.jpg"
    else:
        key = "m1.jpg"

    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        body_bytes = obj["Body"].read()

        # 画像をbase64文字列に
        b64 = base64.b64encode(body_bytes).decode("utf-8")

        resp_body = {
        "image_base64": b64,
        }
        return {
        "statusCode": 200,
        "headers": {**cors_headers, "Content-Type": "application/json"},
        "body": json.dumps(resp_body),
        }


    except s3.exceptions.NoSuchKey:
        return {
        "statusCode": 404,
        "headers": cors_headers,
        "body": json.dumps({"message": f"Not found: s3://{BUCKET}/{key}"}),
        }
    except Exception as e:
        return {
        "statusCode": 500,
        "headers": cors_headers,
        "body": json.dumps({"message": str(e)}),
        }