import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CsvImport {
    public static void main(String[] args) {
        // 💡 引数が4つ揃っているかチェック（足りなければエラーにする）
        if (args.length < 4) {
            System.err.println("【ERROR】必要な引数（URL, User, Password, CSVPath）が不足しています。");
            System.exit(1);
        }

        // 💡 シェルから渡された引数を順番に変数を代入
        String url      = args[0]; // $DB_URL が入る
        String user     = args[1]; // $DB_USER が入る
        String password = args[2]; // $DB_PASSWORD が入る
        String csvFile  = args[3]; // $CSV_FILE_PATH が入る

        // 動作確認用のログ出力
        System.out.println("--- 接続情報を取得しました ---");
        System.out.println("URL     : " + url);
        System.out.println("USER    : " + user);
        System.out.println("CSV FILE: " + csvFile);
        System.out.println("----------------------------");

        try (Connection conn = DriverManager.getConnection(url, user, password);
             BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            String line;
            int rowNum = 0;

            // ヘッダを読み飛ばす
            br.readLine();

            while ((line = br.readLine()) != null) {
                rowNum++;
                String[] data = line.split(",", -1);

                if (data.length < 3) {
                    System.out.println("行 " + rowNum + ": 列数が不足しています");
                    continue;
                }

                String employeeName = data[0].trim();
                String amountStr = data[1].trim();
                String itemName = data[2].trim();

                if (employeeName.isEmpty()) {
                    System.out.println("行 " + rowNum + ": 社員名が空です");
                    continue;
                }

                if (amountStr.isEmpty()) {
                    System.out.println("行 " + rowNum + ": 金額が空です");
                    continue;
                }

                int amount;
                try {
                    amount = Integer.parseInt(amountStr);
                } catch (NumberFormatException e) {
                    System.out.println("行 " + rowNum + ": 金額の形式が不正です");
                    continue;
                }

                if (amount < 0) {
                    System.out.println("行 " + rowNum + ": 金額がマイナスです");
                    continue;
                }

                String sql = "INSERT INTO staging_keihi (employee_name, amount, item_name) VALUES (?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, employeeName);
                    ps.setInt(2, amount);
                    ps.setString(3, itemName);
                    ps.executeUpdate();
                }

                System.out.println("登録完了: " + employeeName + " (行 " + rowNum + ")");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
