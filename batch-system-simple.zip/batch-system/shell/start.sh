#!/bin/bash

# 1. .env ファイルの存在チェックと読み込み
if [ ! -f pg.env ]; then
    echo "【ERROR】pg.env ファイルが見つかりません。"
    exit 1
fi
source pg.env

cd ../java
# 2. 💡 CsvImport.class が存在しない場合、自動でビルド（コンパイル）する
if [ ! -f CsvImport.class ]; then
    echo "【INFO】CsvImport.class が見つからないため、ビルドを実行します..."
    
    # Javaソースファイルがあるかチェック
    if [ ! -f CsvImport.java ]; then
        echo "【ERROR】ビルド対象の CsvImport.java が見つかりません。"
        exit 1
    fi
    
    # コンパイル実行
    javac -cp postgresql-42.7.3.jar CsvImport.java
    
    # コンパイルが成功したかチェック（$? を使用）
    if [ $? -eq 0 ]; then
        echo "【SUCCESS】ビルドが正常に完了しました。"
    else
        echo "【ERROR】ビルド（コンパイル）に失敗しました。ソースコードを確認してください。"
        exit 1
    fi
fi

# ==========================================================
# 💡 【追加】CSVファイルの存在チェック
# ==========================================================
if [ ! -f "$CSV_FILE_PATH" ]; then
    echo "【ERROR】処理対象のCSVファイルが見つかりません。"
    echo "設定されたパス: $CSV_FILE_PATH"
    exit 1  # ここでシェルを異常終了させる
fi
# ==========================================================

# 3. Javaプログラム（CsvImport）を起動
java -cp .:postgresql-42.7.3.jar CsvImport "$DB_URL" "$DB_USER" "$DB_PASSWORD" "$CSV_FILE_PATH"

# 4. Javaの成否判定
if [ $? -eq 0 ]; then
    echo "【SUCCESS】ブリッジ処理が正常終了しました。"
    ../shell/post.sh
else
    echo "【ERROR】ブリッジ処理でエラーが発生しました。"
    exit 1
fi
