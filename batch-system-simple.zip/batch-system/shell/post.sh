#!/bin/bash

INPUT_DIR="../input"
FILE_NAME="keihi.csv"
ARCHIVE_DIR="../archive"

if [ ! -f "$INPUT_DIR/$FILE_NAME" ]; then
  echo "対象ファイルが見つかりません"
  exit 1
fi

mkdir -p "$ARCHIVE_DIR"
mv "$INPUT_DIR/$FILE_NAME" "$ARCHIVE_DIR/"

echo "ファイルを archive へ移動しました"
