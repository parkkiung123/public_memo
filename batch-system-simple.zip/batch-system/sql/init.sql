CREATE TABLE staging_keihi (
    id SERIAL PRIMARY KEY,
    employee_name VARCHAR(100),
    amount INTEGER,
    item_name VARCHAR(100)
);
