#!/bin/bash

# ~/.aws/credentials ファイルを削除
if [ -f ~/.aws/credentials ]; then
  rm ~/.aws/credentials
  echo "AWS CLI credentials ファイルは削除されました。"
else
  echo "AWS CLI credentials ファイルは存在しません。"
fi

# 完了メッセージ
echo "ログアウトが完了しました。"
