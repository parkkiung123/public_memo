#!/bin/bash

# 必要な変数の設定
MFA_ARN="arn:aws:iam::...:mfa/..."  # MFAデバイスのARN
PROFILE_NAME="default"  # AWS CLIのプロファイル名（必要に応じて変更）
REGION="ap-northeast-1"  # 使用するリージョン（必要に応じて変更）

# MFA コードの入力を促す
read -p "Enter MFA code: " MFA_CODE

# MFA を使って一時的なセッションを取得
SESSION_TOKEN=$(aws sts get-session-token \
  --serial-number "$MFA_ARN" \
  --token-code "$MFA_CODE" \
  --profile "$PROFILE_NAME" \
  --region "$REGION" \
  --query "Credentials.[AccessKeyId,SecretAccessKey,SessionToken]" \
  --output text)

# セッション情報を分割して変数に格納
ACCESS_KEY_ID=$(echo $SESSION_TOKEN | awk '{print $1}')
SECRET_ACCESS_KEY=$(echo $SESSION_TOKEN | awk '{print $2}')
SESSION_TOKEN=$(echo $SESSION_TOKEN | awk '{print $3}')

# ~/.aws/credentials に一時的な認証情報を設定
aws configure set aws_access_key_id "$ACCESS_KEY_ID" --profile "$PROFILE_NAME"
aws configure set aws_secret_access_key "$SECRET_ACCESS_KEY" --profile "$PROFILE_NAME"
aws configure set aws_session_token "$SESSION_TOKEN" --profile "$PROFILE_NAME"

# ~/.aws/config にリージョン設定を追加
aws configure set region "$REGION" --profile "$PROFILE_NAME"

# MFA 認証成功メッセージ
echo "MFA認証成功。AWS CLIコマンドが実行できます。"
