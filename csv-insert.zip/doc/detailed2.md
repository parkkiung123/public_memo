# 詳細設計

## バッチ処理フロー

```text
開始
  ↓
設定ファイル読み込み
  ↓
CSVファイル存在確認
  ↓
CSV読み込み
  ↓
ヘッダー確認
  ↓
1行ずつデータ処理
  ↓
項目整形
  ↓
入力チェック
  ↓
正常ならDB INSERT
  ↓
異常ならエラーCSV出力
  ↓
処理結果ログ出力
  ↓
CSVをbackupへ移動
  ↓
終了
```

## 入力チェック仕様

| 項目 | チェック内容 |
|---|---|
| 顧客ID | 必須、重複不可 |
| 氏名 | 必須 |
| メールアドレス | 必須、メール形式 |
| 電話番号 | 数字・ハイフンのみ |
| 郵便番号 | 7桁またはハイフン付き |
| 登録日 | 日付形式 `YYYY-MM-DD` |

## データ整形仕様

| 項目 | 整形内容 |
|---|---|
| 氏名 | 前後空白除去 |
| メールアドレス | 前後空白除去、小文字化 |
| 電話番号 | 不要な空白除去 |
| 郵便番号 | ハイフン除去または統一形式へ変換 |
| 登録日 | DB登録用日付型へ変換 |

## INSERT先テーブル例

テーブル名：`customers`

| カラム | 型 | 内容 |
|---|---|---|
| customer_id | VARCHAR | 顧客ID |
| customer_name | VARCHAR | 氏名 |
| email | VARCHAR | メールアドレス |
| phone_number | VARCHAR | 電話番号 |
| postal_code | VARCHAR | 郵便番号 |
| address | VARCHAR | 住所 |
| registered_date | DATE | 登録日 |
| created_at | TIMESTAMP | 作成日時 |

## INSERT SQL例

```sql
INSERT INTO customers (
  customer_id,
  customer_name,
  email,
  phone_number,
  postal_code,
  address,
  registered_date,
  created_at
) VALUES (
  ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
);
```

## ログ出力内容

| ログ種別 | 内容 |
|---|---|
| INFO | 処理開始、処理終了、件数 |
| WARN | 入力ファイルなし、スキップ行 |
| ERROR | CSV不正、DB接続失敗、INSERT失敗 |

## 件数出力例

```text
処理開始: customer.csv
読込件数: 100
登録成功件数: 95
エラー件数: 5
処理終了
```

## 最小構成の設定項目

```properties
input.dir=/input
backup.dir=/backup
error.dir=/error
log.dir=/log
db.url=jdbc:postgresql://host:5432/dbname
db.user=user
db.password=password
```