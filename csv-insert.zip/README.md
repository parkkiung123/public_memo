# CSV Insert Batch

顧客情報 CSV を整形・検証し、外部 DB の `customers` テーブルへ INSERT する最小構成の Java + shell バッチです。

## Build

```sh
mvn package
```

## Run

/mnt/c/Users/interline/Documents/Codex/2026-05-19/csv-insert
```sh
sh shell/run_customer_import.sh
```

PostgreSQL など外部 DB に接続する場合は、`config/batch.properties` の `db.*` を変更し、JDBC ドライバ jar を `lib/` に置いてください。起動 shell が `target` のバッチ jar と `lib/*.jar` を classpath に含めて起動します。

```sh
sh shell/run_customer_import.sh
```

## Exit Codes

| Code | Meaning |
|---:|---|
| 0 | 正常終了 |
| 1 | データエラーあり |
| 8 | DB エラー |
| 9 | 設定・ファイル不備 |
