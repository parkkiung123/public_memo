#!/bin/sh

BASE_DIR=$(cd "$(dirname "$0")/.." && pwd)
CONFIG_FILE="${1:-${BASE_DIR}/config/batch.properties}"
JAR_FILE="${BASE_DIR}/target/csv-insert-batch-1.0.0.jar"
LIB_DIR="${BASE_DIR}/lib"
LOG_DIR="${BASE_DIR}/log"
LOG_FILE="${LOG_DIR}/customer_import_$(date +%Y%m%d).log"

mkdir -p "${LOG_DIR}"

echo "batch start: $(date '+%Y-%m-%d %H:%M:%S')" >> "${LOG_FILE}"

if [ ! -f "${CONFIG_FILE}" ]; then
  echo "config file not found: ${CONFIG_FILE}" >> "${LOG_FILE}"
  exit 9
fi

if [ ! -f "${JAR_FILE}" ]; then
  echo "jar file not found: ${JAR_FILE}" >> "${LOG_FILE}"
  exit 9
fi

java -cp "${JAR_FILE}:${LIB_DIR}/*" com.example.batch.CustomerImportBatch "${CONFIG_FILE}" >> "${LOG_FILE}" 2>&1
RET=$?

if [ "${RET}" -eq 0 ]; then
  echo "batch normal end: $(date '+%Y-%m-%d %H:%M:%S')" >> "${LOG_FILE}"
else
  echo "batch abnormal end. code=${RET}: $(date '+%Y-%m-%d %H:%M:%S')" >> "${LOG_FILE}"
fi

exit "${RET}"
