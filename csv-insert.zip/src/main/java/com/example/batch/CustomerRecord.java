package com.example.batch;

import java.time.LocalDate;

record CustomerRecord(
        String customerId,
        String name,
        String email,
        String phone,
        String postalCode,
        String address,
        LocalDate registeredDate) {
}
