package com.example.batch;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

final class CustomerDao implements AutoCloseable {
    private final Connection connection;
    private final PreparedStatement insertStatement;

    CustomerDao(BatchConfig config) throws SQLException, ClassNotFoundException {
        String driver = config.optional("db.driver");
        if (!driver.isEmpty()) {
            Class.forName(driver);
        }
        this.connection = DriverManager.getConnection(
                config.required("db.url"),
                config.required("db.user"),
                config.required("db.password"));
        this.connection.setAutoCommit(false);
        this.insertStatement = connection.prepareStatement(buildInsertSql(config.required("db.table")));
    }

    void insert(CustomerRecord record) throws SQLException {
        try {
            insertStatement.setString(1, record.customerId());
            insertStatement.setString(2, record.name());
            insertStatement.setString(3, record.email());
            insertStatement.setString(4, record.phone());
            insertStatement.setString(5, record.postalCode());
            insertStatement.setString(6, record.address());
            insertStatement.setDate(7, Date.valueOf(record.registeredDate()));
            insertStatement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            rollback();
            throw e;
        }
    }

    private void rollback() {
        try {
            connection.rollback();
        } catch (SQLException e) {
            System.err.println("rollback failed: " + e.getMessage());
        }
    }

    @Override
    public void close() throws SQLException {
        insertStatement.close();
        connection.close();
    }

    private static String buildInsertSql(String table) {
        if (!table.matches("[A-Za-z_][A-Za-z0-9_]*")) {
            throw new IllegalArgumentException("Invalid table name: " + table);
        }
        return "INSERT INTO " + table + " ("
                + "customer_id, customer_name, email, phone_number, postal_code, address, registered_date, created_at"
                + ") VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
    }
}
