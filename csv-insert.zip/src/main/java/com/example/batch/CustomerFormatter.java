package com.example.batch;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

final class CustomerFormatter {
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;

    private CustomerFormatter() {
    }

    static CustomerRecord format(List<String> values) {
        String customerId = value(values, 0).trim();
        String name = value(values, 1).trim();
        String email = value(values, 2).trim().toLowerCase();
        String phone = value(values, 3).trim().replace(" ", "").replace("　", "");
        String postalCode = value(values, 4).trim().replace("-", "");
        String address = value(values, 5).trim();
        LocalDate registeredDate = parseDate(value(values, 6).trim());
        return new CustomerRecord(customerId, name, email, phone, postalCode, address, registeredDate);
    }

    private static String value(List<String> values, int index) {
        return index < values.size() ? values.get(index) : "";
    }

    private static LocalDate parseDate(String value) {
        if (value.isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(value, DATE_FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
