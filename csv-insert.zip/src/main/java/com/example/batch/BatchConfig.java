package com.example.batch;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

final class BatchConfig {
    private final Path configPath;
    private final Properties properties;

    private BatchConfig(Path configPath, Properties properties) {
        this.configPath = configPath;
        this.properties = properties;
    }

    static BatchConfig load(String filePath) throws IOException {
        Path path = Path.of(filePath).toAbsolutePath().normalize();
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
        }
        return new BatchConfig(path, props);
    }

    Path resolvePath(String key) {
        String value = required(key);
        Path path = Path.of(value);
        if (path.isAbsolute()) {
            return path.normalize();
        }
        Path configDir = configPath.getParent() == null ? Path.of(".") : configPath.getParent();
        Path baseDir = configDir;
        if (configDir.getFileName() != null && "config".equals(configDir.getFileName().toString())) {
            baseDir = configDir.getParent() == null ? configDir : configDir.getParent();
        }
        return baseDir.resolve(path).toAbsolutePath().normalize();
    }

    String required(String key) {
        String value = properties.getProperty(key);
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("Required property is missing: " + key);
        }
        return value.trim();
    }

    String optional(String key) {
        String value = properties.getProperty(key);
        return value == null ? "" : value.trim();
    }
}
