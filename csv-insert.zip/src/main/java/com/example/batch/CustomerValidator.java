package com.example.batch;

import java.util.ArrayList;
import java.util.List;

final class CustomerValidator {
    private CustomerValidator() {
    }

    static List<String> validate(CustomerRecord record, int columnCount) {
        List<String> errors = new ArrayList<>();

        if (columnCount != 7) {
            errors.add("column count must be 7");
        }
        if (record.customerId().isEmpty()) {
            errors.add("customer_id is required");
        }
        if (record.name().isEmpty()) {
            errors.add("name is required");
        }
        if (record.email().isEmpty()) {
            errors.add("email is required");
        } else if (!record.email().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            errors.add("email format is invalid");
        }
        if (!record.phone().isEmpty() && !record.phone().matches("^[0-9-]+$")) {
            errors.add("phone format is invalid");
        }
        if (!record.postalCode().isEmpty() && !record.postalCode().matches("^[0-9]{7}$")) {
            errors.add("postal_code format is invalid");
        }
        if (record.registeredDate() == null) {
            errors.add("registered_date must be yyyy-MM-dd");
        }

        return errors;
    }
}
