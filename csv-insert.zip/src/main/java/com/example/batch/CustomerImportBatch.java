package com.example.batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class CustomerImportBatch {
    private static final int EXIT_OK = 0;
    private static final int EXIT_DATA_ERROR = 1;
    private static final int EXIT_DB_ERROR = 8;
    private static final int EXIT_CONFIG_ERROR = 9;
    private static final List<String> EXPECTED_HEADER = List.of(
            "customer_id", "name", "email", "phone", "postal_code", "address", "registered_date");

    private CustomerImportBatch() {
    }

    public static void main(String[] args) {
        int exitCode = run(args);
        System.exit(exitCode);
    }

    static int run(String[] args) {
        if (args.length != 1) {
            System.err.println("usage: java -jar csv-insert-batch-1.0.0.jar <batch.properties>");
            return EXIT_CONFIG_ERROR;
        }

        try {
            return execute(BatchConfig.load(args[0]));
        } catch (IllegalArgumentException | IOException e) {
            System.err.println("config/file error: " + e.getMessage());
            return EXIT_CONFIG_ERROR;
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("db error: " + e.getMessage());
            return EXIT_DB_ERROR;
        }
    }

    private static int execute(BatchConfig config) throws IOException, SQLException, ClassNotFoundException {
        Path inputFile = config.resolvePath("input.file");
        Path backupDir = config.resolvePath("backup.dir");
        Path errorFile = config.resolvePath("error.file");
        Charset charset = Charset.forName(config.optional("csv.charset").isEmpty() ? "UTF-8" : config.optional("csv.charset"));

        if (!Files.isRegularFile(inputFile)) {
            throw new IOException("input file not found: " + inputFile);
        }

        Files.createDirectories(backupDir);
        Files.createDirectories(errorFile.getParent());

        int readCount = 0;
        int successCount = 0;
        int errorCount = 0;

        System.out.println("input file: " + inputFile);

        try (BufferedReader reader = Files.newBufferedReader(inputFile, charset);
             BufferedWriter errorWriter = Files.newBufferedWriter(errorFile, charset);
             CustomerDao dao = new CustomerDao(config)) {

            String headerLine = reader.readLine();
            validateHeader(headerLine);
            errorWriter.write(headerLine + ",error_reason");
            errorWriter.newLine();

            String line;
            while ((line = reader.readLine()) != null) {
                readCount++;
                if (line.isBlank()) {
                    continue;
                }

                List<String> values = CsvUtils.parseLine(line);
                CustomerRecord record = CustomerFormatter.format(values);
                List<String> errors = CustomerValidator.validate(record, values.size());
                if (!errors.isEmpty()) {
                    errorCount++;
                    writeError(errorWriter, values, String.join("; ", errors));
                    continue;
                }

                try {
                    dao.insert(record);
                    successCount++;
                } catch (SQLException e) {
                    errorCount++;
                    writeError(errorWriter, values, "insert failed: " + e.getMessage());
                }
            }

            System.out.println("valid rows are committed one by one.");
        }

        backupInputFile(inputFile, backupDir);

        System.out.println("read count: " + readCount);
        System.out.println("insert success count: " + successCount);
        System.out.println("error count: " + errorCount);

        return errorCount == 0 ? EXIT_OK : EXIT_DATA_ERROR;
    }

    private static void validateHeader(String headerLine) throws IOException {
        if (headerLine == null) {
            throw new IOException("input csv is empty");
        }
        List<String> header = CsvUtils.parseLine(headerLine).stream().map(String::trim).toList();
        if (!EXPECTED_HEADER.equals(header)) {
            throw new IOException("invalid header: " + header);
        }
    }

    private static void writeError(BufferedWriter writer, List<String> values, String reason) throws IOException {
        values.add(reason);
        writer.write(CsvUtils.toLine(values));
        writer.newLine();
    }

    private static void backupInputFile(Path inputFile, Path backupDir) throws IOException {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String backupName = timestamp + "_" + inputFile.getFileName();
        Files.move(inputFile, backupDir.resolve(backupName), StandardCopyOption.REPLACE_EXISTING);
    }
}
