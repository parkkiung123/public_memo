Put external JDBC driver jars here.

Examples:

- PostgreSQL: `postgresql-*.jar`
- MySQL: `mysql-connector-j-*.jar`
