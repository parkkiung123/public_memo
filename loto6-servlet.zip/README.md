# Loto6 Servlet API

Java Servlet + Maven WAR で作ったロト6 APIです。

## Build

```powershell
mvn package
```

生成物:

```text
target/loto6-api.war
```

Tomcat 10系など Jakarta Servlet 6 対応のコンテナに `loto6-api.war` を配置してください。

## Test

```powershell
mvn test
```

JUnit 5 でサーブレットを直接呼び出し、以下を確認します。

- `GET /api/check` が当選回、当選ランク、当選金額を返すこと
- 不正なスペース区切り番号に `400` を返すこと
- `POST /api/check` が本文のスペース区切り番号を受け付けること
- `GET /api/recommend` が6個のおすすめ番号と最新開催回を返すこと

## API

### 当選チェック

```text
GET /loto6-api/api/check?numbers=2%205%2010%2023%2024%207
POST /loto6-api/api/check
Body: 2 5 10 23 24 7
```

入力はスペース区切りの6数字です。数字は1から43、重複不可です。

レスポンス例:

```json
{
  "requestNumbers": [2, 5, 10, 23, 24, 7],
  "winningCount": 10,
  "winnings": [
    {
      "drawNo": 2100,
      "date": "2026/5/7",
      "rank": "5等",
      "amount": 1000,
      "mainMatches": 3,
      "bonusMatch": false
    }
  ]
}
```

### 今日のあたり予感番号

```text
GET /loto6-api/api/recommend
```

過去全期間の出現頻度、直近100回の重み、今日の日付シードを使って6数字を返します。

## ランク判定

```text
1等: 本数字6個一致
2等: 本数字5個一致 + BONUS一致
3等: 本数字5個一致
4等: 本数字4個一致
5等: 本数字3個一致
```
