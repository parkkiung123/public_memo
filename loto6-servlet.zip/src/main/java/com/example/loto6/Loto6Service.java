package com.example.loto6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

final class Loto6Service {
    private static final String CSV_RESOURCE = "/loto6.csv";
    private final List<Loto6Record> records;

    Loto6Service() throws IOException {
        this.records = loadRecords();
    }

    List<WinningResult> check(String rawNumbers) {
        Set<Integer> requestNumbers = parseNumbers(rawNumbers);
        List<WinningResult> results = new ArrayList<>();

        for (Loto6Record record : records) {
            int mainMatches = 0;
            for (int number : requestNumbers) {
                if (record.mainNumbers.contains(number)) {
                    mainMatches++;
                }
            }

            boolean bonusMatch = requestNumbers.contains(record.bonusNumber);
            Prize prize = prizeFor(record, mainMatches, bonusMatch);
            if (prize != null) {
                results.add(new WinningResult(record, prize, mainMatches, bonusMatch));
            }
        }

        results.sort(Comparator.comparingInt((WinningResult result) -> result.drawNo).reversed());
        return results;
    }

    Recommendation recommend() {
        int[] totalFrequency = new int[44];
        int[] recentFrequency = new int[44];
        int recentStart = Math.max(0, records.size() - 100);

        for (int index = 0; index < records.size(); index++) {
            int weight = index >= recentStart ? 2 : 1;
            for (int number : records.get(index).mainNumbers) {
                totalFrequency[number]++;
                recentFrequency[number] += weight;
            }
        }

        int daySeed = LocalDate.now().getDayOfYear();
        List<ScoredNumber> scoredNumbers = new ArrayList<>();
        for (int number = 1; number <= 43; number++) {
            int score = (totalFrequency[number] * 3) + (recentFrequency[number] * 5) + ((number * daySeed) % 17);
            scoredNumbers.add(new ScoredNumber(number, score, totalFrequency[number], recentFrequency[number]));
        }

        scoredNumbers.sort(Comparator.comparingInt((ScoredNumber item) -> item.score).reversed()
                .thenComparingInt(item -> item.number));

        List<Integer> numbers = scoredNumbers.stream()
                .limit(6)
                .map(item -> item.number)
                .sorted()
                .collect(Collectors.toList());

        List<ScoredNumber> basis = scoredNumbers.stream().limit(10).collect(Collectors.toList());
        return new Recommendation(numbers, basis, records.get(records.size() - 1));
    }

    Set<Integer> parseNumbers(String rawNumbers) {
        if (rawNumbers == null || rawNumbers.trim().isEmpty()) {
            throw new IllegalArgumentException("numbers is required. Example: 2 5 10 23 24 7");
        }

        String[] tokens = rawNumbers.trim().split("\\s+");
        if (tokens.length != 6) {
            throw new IllegalArgumentException("Please send exactly 6 numbers separated by spaces.");
        }

        Set<Integer> numbers = new LinkedHashSet<>();
        for (String token : tokens) {
            int number;
            try {
                number = Integer.parseInt(token);
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("All values must be numbers.");
            }
            if (number < 1 || number > 43) {
                throw new IllegalArgumentException("Numbers must be between 1 and 43.");
            }
            if (!numbers.add(number)) {
                throw new IllegalArgumentException("Duplicate numbers are not allowed.");
            }
        }
        return numbers;
    }

    private Prize prizeFor(Loto6Record record, int mainMatches, boolean bonusMatch) {
        if (mainMatches == 6) {
            return new Prize("1等", record.firstPrize);
        }
        if (mainMatches == 5 && bonusMatch) {
            return new Prize("2等", record.secondPrize);
        }
        if (mainMatches == 5) {
            return new Prize("3等", record.thirdPrize);
        }
        if (mainMatches == 4) {
            return new Prize("4等", record.fourthPrize);
        }
        if (mainMatches == 3) {
            return new Prize("5等", record.fifthPrize);
        }
        return null;
    }

    private List<Loto6Record> loadRecords() throws IOException {
        InputStream stream = Loto6Service.class.getResourceAsStream(CSV_RESOURCE);
        if (stream == null) {
            throw new IOException("loto6.csv was not found on the classpath.");
        }

        List<Loto6Record> loaded = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                String[] columns = line.split(",", -1);
                Set<Integer> mainNumbers = new HashSet<>();
                for (int index = 2; index <= 7; index++) {
                    mainNumbers.add(parseInt(columns[index]));
                }
                loaded.add(new Loto6Record(
                        parseInt(columns[0]),
                        columns[1],
                        mainNumbers,
                        parseInt(columns[8]),
                        parseLong(columns[14]),
                        parseLong(columns[15]),
                        parseLong(columns[16]),
                        parseLong(columns[17]),
                        parseLong(columns[18])));
            }
        }

        if (loaded.isEmpty()) {
            throw new IOException("loto6.csv has no records.");
        }
        return loaded;
    }

    private int parseInt(String value) {
        return Integer.parseInt(value.trim());
    }

    private long parseLong(String value) {
        return Long.parseLong(value.trim());
    }

    record Prize(String rank, long amount) {
    }

    record WinningResult(int drawNo, String date, String rank, long amount, int mainMatches, boolean bonusMatch) {
        WinningResult(Loto6Record record, Prize prize, int mainMatches, boolean bonusMatch) {
            this(record.drawNo, record.date, prize.rank(), prize.amount(), mainMatches, bonusMatch);
        }
    }

    record Recommendation(List<Integer> numbers, List<ScoredNumber> basis, Loto6Record latestRecord) {
    }

    record ScoredNumber(int number, int score, int totalFrequency, int recentWeightedFrequency) {
    }
}
