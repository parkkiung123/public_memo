package com.example.loto6;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/api/check", "/api/recommend"})
public class Loto6Servlet extends HttpServlet {
    private Loto6Service service;

    @Override
    public void init() throws ServletException {
        try {
            service = new Loto6Service();
        } catch (IOException ex) {
            throw new ServletException("Failed to load loto6.csv", ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        handle(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        try {
            String path = request.getServletPath();
            if ("/api/check".equals(path)) {
                writeCheckResponse(request, response);
            } else if ("/api/recommend".equals(path)) {
                writeRecommendResponse(response);
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{\"error\":\"not found\"}");
            }
        } catch (IllegalArgumentException ex) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\":\"" + json(ex.getMessage()) + "\"}");
        }
    }

    private void writeCheckResponse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String rawNumbers = request.getParameter("numbers");
        if (rawNumbers == null && "POST".equalsIgnoreCase(request.getMethod())) {
            rawNumbers = request.getReader().readLine();
        }

        Set<Integer> parsedNumbers = service.parseNumbers(rawNumbers);
        List<Loto6Service.WinningResult> results = service.check(rawNumbers);

        StringBuilder json = new StringBuilder();
        json.append("{\"requestNumbers\":").append(numberArray(parsedNumbers))
                .append(",\"winningCount\":").append(results.size())
                .append(",\"winnings\":[");

        for (int index = 0; index < results.size(); index++) {
            Loto6Service.WinningResult result = results.get(index);
            if (index > 0) {
                json.append(',');
            }
            json.append("{\"drawNo\":").append(result.drawNo())
                    .append(",\"date\":\"").append(json(result.date()))
                    .append("\",\"rank\":\"").append(json(result.rank()))
                    .append("\",\"amount\":").append(result.amount())
                    .append(",\"mainMatches\":").append(result.mainMatches())
                    .append(",\"bonusMatch\":").append(result.bonusMatch())
                    .append('}');
        }
        json.append("]}");
        response.getWriter().write(json.toString());
    }

    private void writeRecommendResponse(HttpServletResponse response) throws IOException {
        Loto6Service.Recommendation recommendation = service.recommend();

        StringBuilder json = new StringBuilder();
        json.append("{\"recommendedNumbers\":").append(numberArray(recommendation.numbers()))
                .append(",\"method\":\"過去全期間の出現頻度、直近100回の重み、今日の日付シードを使ったスコア順です。\"")
                .append(",\"latestDraw\":{\"drawNo\":").append(recommendation.latestRecord().drawNo)
                .append(",\"date\":\"").append(json(recommendation.latestRecord().date))
                .append("\"},\"basis\":[");

        for (int index = 0; index < recommendation.basis().size(); index++) {
            Loto6Service.ScoredNumber item = recommendation.basis().get(index);
            if (index > 0) {
                json.append(',');
            }
            json.append("{\"number\":").append(item.number())
                    .append(",\"score\":").append(item.score())
                    .append(",\"totalFrequency\":").append(item.totalFrequency())
                    .append(",\"recentWeightedFrequency\":").append(item.recentWeightedFrequency())
                    .append('}');
        }

        json.append("]}");
        response.getWriter().write(json.toString());
    }

    private String numberArray(Iterable<Integer> numbers) {
        StringBuilder json = new StringBuilder("[");
        boolean first = true;
        for (int number : numbers) {
            if (!first) {
                json.append(',');
            }
            json.append(number);
            first = false;
        }
        return json.append(']').toString();
    }

    private String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
