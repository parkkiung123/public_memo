package com.example.loto6;

import java.util.Set;

final class Loto6Record {
    final int drawNo;
    final String date;
    final Set<Integer> mainNumbers;
    final int bonusNumber;
    final long firstPrize;
    final long secondPrize;
    final long thirdPrize;
    final long fourthPrize;
    final long fifthPrize;

    Loto6Record(int drawNo, String date, Set<Integer> mainNumbers, int bonusNumber,
                long firstPrize, long secondPrize, long thirdPrize, long fourthPrize, long fifthPrize) {
        this.drawNo = drawNo;
        this.date = date;
        this.mainNumbers = mainNumbers;
        this.bonusNumber = bonusNumber;
        this.firstPrize = firstPrize;
        this.secondPrize = secondPrize;
        this.thirdPrize = thirdPrize;
        this.fourthPrize = fourthPrize;
        this.fifthPrize = fifthPrize;
    }
}
