(function () {
  const { useMemo, useState } = React;

  const sampleNumbers = "1 17 29 33 40 42";

  function App() {
    const [numbers, setNumbers] = useState(sampleNumbers);
    const [checkResult, setCheckResult] = useState(null);
    const [recommendation, setRecommendation] = useState(null);
    const [loading, setLoading] = useState("");
    const [error, setError] = useState("");

    const normalizedNumbers = useMemo(() => {
      return numbers.trim().split(/\s+/).filter(Boolean);
    }, [numbers]);

    async function callApi(path, options) {
      setError("");
      const response = await fetch(path, options);
      const json = await response.json();
      if (!response.ok) {
        throw new Error(json.error || "API request failed.");
      }
      return json;
    }

    async function checkNumbers(event) {
      event.preventDefault();
      setLoading("check");
      try {
        const query = encodeURIComponent(numbers.trim());
        const json = await callApi(`api/check?numbers=${query}`);
        setCheckResult(json);
      } catch (ex) {
        setError(ex.message);
      } finally {
        setLoading("");
      }
    }

    async function getRecommendation() {
      setLoading("recommend");
      try {
        const json = await callApi("api/recommend");
        setRecommendation(json);
      } catch (ex) {
        setError(ex.message);
      } finally {
        setLoading("");
      }
    }

    function useRecommendationNumbers() {
      if (!recommendation) {
        return;
      }
      setNumbers(recommendation.recommendedNumbers.join(" "));
    }

    return React.createElement(
      "main",
      { className: "app-shell" },
      React.createElement(
        "section",
        { className: "masthead" },
        React.createElement("div", { className: "draw-mark", "aria-hidden": "true" },
          React.createElement("span", null, "06")
        ),
        React.createElement(
          "div",
          null,
          React.createElement("p", { className: "eyebrow" }, "Loto6 API Client"),
          React.createElement("h1", null, "ロト6 当選チェック"),
          React.createElement("p", { className: "lead" }, "スペース区切りの6数字で、過去の当選回・ランク・賞金を確認できます。")
        )
      ),
      React.createElement(
        "section",
        { className: "tool-grid" },
        React.createElement(
          "form",
          { className: "panel input-panel", onSubmit: checkNumbers },
          React.createElement("label", { htmlFor: "numbers" }, "入力番号"),
          React.createElement("input", {
            id: "numbers",
            value: numbers,
            onChange: (event) => setNumbers(event.target.value),
            inputMode: "numeric",
            placeholder: "2 5 10 23 24 7"
          }),
          React.createElement(
            "div",
            { className: "number-preview", "aria-label": "入力された数字" },
            normalizedNumbers.map((number, index) =>
              React.createElement("span", { key: `${number}-${index}` }, number)
            )
          ),
          React.createElement(
            "div",
            { className: "actions" },
            React.createElement(
              "button",
              { type: "submit", disabled: loading === "check" },
              loading === "check" ? "確認中" : "当選チェック"
            ),
            React.createElement(
              "button",
              { type: "button", className: "secondary", onClick: getRecommendation, disabled: loading === "recommend" },
              loading === "recommend" ? "取得中" : "今日のおすすめ"
            )
          ),
          error && React.createElement("p", { className: "error", role: "alert" }, error)
        ),
        React.createElement(RecommendationPanel, {
          recommendation,
          onUseNumbers: useRecommendationNumbers
        })
      ),
      React.createElement(ResultsPanel, { result: checkResult })
    );
  }

  function RecommendationPanel({ recommendation, onUseNumbers }) {
    return React.createElement(
      "aside",
      { className: "panel recommendation-panel" },
      React.createElement("div", { className: "panel-header" },
        React.createElement("div", null,
          React.createElement("p", { className: "eyebrow" }, "Today"),
          React.createElement("h2", null, "あたり予感番号")
        ),
        React.createElement("button", {
          type: "button",
          className: "icon-button",
          onClick: onUseNumbers,
          disabled: !recommendation,
          title: "おすすめ番号を入力欄へ反映"
        }, "↙")
      ),
      recommendation
        ? React.createElement(React.Fragment, null,
            React.createElement("div", { className: "number-row" },
              recommendation.recommendedNumbers.map((number) =>
                React.createElement("span", { key: number }, number)
              )
            ),
            React.createElement("p", { className: "muted" }, recommendation.method),
            React.createElement("p", { className: "latest" },
              `最新データ: 第${recommendation.latestDraw.drawNo}回 ${recommendation.latestDraw.date}`
            )
          )
        : React.createElement("p", { className: "empty" }, "ボタンを押すとAPIからおすすめ番号を取得します。")
    );
  }

  function ResultsPanel({ result }) {
    return React.createElement(
      "section",
      { className: "results-section" },
      React.createElement("div", { className: "section-title" },
        React.createElement("h2", null, "当選結果"),
        result && React.createElement("span", null, `${result.winningCount}件`)
      ),
      !result
        ? React.createElement("div", { className: "empty-state" }, "番号を入力して当選チェックを実行してください。")
        : result.winnings.length === 0
          ? React.createElement("div", { className: "empty-state" }, "該当する当選回はありませんでした。")
          : React.createElement(
              "div",
              { className: "table-wrap" },
              React.createElement(
                "table",
                null,
                React.createElement("thead", null,
                  React.createElement("tr", null,
                    React.createElement("th", null, "開催回"),
                    React.createElement("th", null, "日付"),
                    React.createElement("th", null, "ランク"),
                    React.createElement("th", null, "賞金"),
                    React.createElement("th", null, "一致")
                  )
                ),
                React.createElement("tbody", null,
                  result.winnings.map((item) =>
                    React.createElement("tr", { key: item.drawNo },
                      React.createElement("td", null, `第${item.drawNo}回`),
                      React.createElement("td", null, item.date),
                      React.createElement("td", null, React.createElement("strong", null, item.rank)),
                      React.createElement("td", null, `${item.amount.toLocaleString("ja-JP")}円`),
                      React.createElement("td", null, `${item.mainMatches}個${item.bonusMatch ? " + BONUS" : ""}`)
                    )
                  )
                )
              )
            )
    );
  }

  ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(App));
})();
