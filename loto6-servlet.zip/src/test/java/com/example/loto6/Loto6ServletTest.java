package com.example.loto6;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Loto6ServletTest {
    private Loto6Servlet servlet;

    @BeforeEach
    void setUp() throws Exception {
        servlet = new Loto6Servlet();
        servlet.init();
    }

    @Test
    void checkApiReturnsWinningDrawRankAndAmount() throws Exception {
        TestResponse response = new TestResponse();
        HttpServletRequest request = request("GET", "/api/check", Map.of("numbers", "1 17 29 33 40 42"), "");

        servlet.doGet(request, response.proxy());

        String body = response.body();
        assertEquals(200, response.status());
        assertTrue(body.contains("\"drawNo\":2101"));
        assertTrue(body.contains("\"rank\":\"1等\""));
        assertTrue(body.contains("\"amount\":119417600"));
        assertTrue(body.contains("\"mainMatches\":6"));
    }

    @Test
    void checkApiRejectsInvalidSpaceDelimitedNumbers() throws Exception {
        TestResponse response = new TestResponse();
        HttpServletRequest request = request("GET", "/api/check", Map.of("numbers", "1 2 3"), "");

        servlet.doGet(request, response.proxy());

        assertEquals(400, response.status());
        assertTrue(response.body().contains("exactly 6 numbers"));
    }

    @Test
    void checkApiAcceptsPostBody() throws Exception {
        TestResponse response = new TestResponse();
        HttpServletRequest request = request("POST", "/api/check", new HashMap<>(), "1 17 29 33 40 42");

        servlet.doPost(request, response.proxy());

        assertEquals(200, response.status());
        assertTrue(response.body().contains("\"drawNo\":2101"));
    }

    @Test
    void recommendApiReturnsSixNumbersAndLatestDraw() throws Exception {
        TestResponse response = new TestResponse();
        HttpServletRequest request = request("GET", "/api/recommend", new HashMap<>(), "");

        servlet.doGet(request, response.proxy());

        String body = response.body();
        assertEquals(200, response.status());
        assertTrue(body.matches(".*\"recommendedNumbers\":\\[[0-9,]+\\].*"));
        assertTrue(body.contains("\"latestDraw\":{\"drawNo\":2101"));
        assertTrue(body.contains("\"basis\":["));
    }

    private HttpServletRequest request(String method, String servletPath, Map<String, String> parameters, String body) {
        return (HttpServletRequest) Proxy.newProxyInstance(
                HttpServletRequest.class.getClassLoader(),
                new Class<?>[]{HttpServletRequest.class},
                (proxy, methodCall, args) -> switch (methodCall.getName()) {
                    case "getMethod" -> method;
                    case "getServletPath" -> servletPath;
                    case "getParameter" -> parameters.get((String) args[0]);
                    case "getReader" -> new BufferedReader(new StringReader(body));
                    case "toString" -> method + " " + servletPath;
                    default -> defaultValue(methodCall.getReturnType());
                });
    }

    private Object defaultValue(Class<?> returnType) {
        if (!returnType.isPrimitive()) {
            return null;
        }
        if (returnType == boolean.class) {
            return false;
        }
        if (returnType == int.class) {
            return 0;
        }
        if (returnType == long.class) {
            return 0L;
        }
        if (returnType == double.class) {
            return 0.0d;
        }
        if (returnType == float.class) {
            return 0.0f;
        }
        if (returnType == byte.class) {
            return (byte) 0;
        }
        if (returnType == short.class) {
            return (short) 0;
        }
        if (returnType == char.class) {
            return '\0';
        }
        return null;
    }

    private final class TestResponse {
        private final StringWriter body = new StringWriter();
        private final PrintWriter writer = new PrintWriter(body);
        private int status = 200;

        HttpServletResponse proxy() {
            return (HttpServletResponse) Proxy.newProxyInstance(
                    HttpServletResponse.class.getClassLoader(),
                    new Class<?>[]{HttpServletResponse.class},
                    (proxy, methodCall, args) -> switch (methodCall.getName()) {
                        case "getWriter" -> writer;
                        case "setStatus" -> {
                            status = (int) args[0];
                            yield null;
                        }
                        case "toString" -> body.toString();
                        default -> defaultValue(methodCall.getReturnType());
                    });
        }

        int status() {
            return status;
        }

        String body() {
            writer.flush();
            return body.toString();
        }
    }
}
